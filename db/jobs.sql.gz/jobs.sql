PRAGMA foreign_keys=OFF;
BEGIN TRANSACTION;
CREATE TABLE postings (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,

    -- Origin
    source          TEXT NOT NULL,          -- 'greenhouse', 'lever', 'usajobs', 'neogov', ...
    source_job_id   TEXT NOT NULL,          -- the ATS's own ID for this posting
    company         TEXT NOT NULL,          -- canonical company name (matches targets.csv)

    -- Posting content
    role            TEXT NOT NULL,          -- role title
    location        TEXT,                   -- as posted — e.g. "Washington, DC" or "Remote - US"
    department      TEXT,                   -- ATS-provided dept/team if any
    url             TEXT NOT NULL,          -- link to the posting
    jd_text         TEXT,                   -- full job description (may be long)

    -- Metadata
    posted_at       TEXT,                   -- ISO-8601 UTC, if the ATS provides it
    first_seen      TEXT NOT NULL,          -- ISO-8601 UTC, when WE first saw this posting
    last_seen       TEXT NOT NULL,          -- ISO-8601 UTC, most recent scrape that still saw it
    is_active       INTEGER NOT NULL DEFAULT 1,  -- 0 = no longer appearing in source feed

    -- Scoring (populated by scoring module later)
    fit_score       REAL,                   -- 0.0 - 1.0, NULL until scored
    score_notes     TEXT,                   -- why it scored that way

    -- Interest level (D27 — per-posting triage signal, separate from fit_score)
    interest_level  TEXT NOT NULL DEFAULT 'not_reviewed',
        -- valid values: 'not_reviewed' (default), 'not_interested',
        --               'interested', 'very_interested'
    interest_updated_at TEXT,           -- ISO-8601 UTC, set on every interest change.
                                        -- Feeds daily-streak computation (D33). NULL = never changed.

    UNIQUE (source, source_job_id)
);
INSERT INTO postings VALUES(101,'greenjobs','https://greenjobs.greenjobsearch.org/?post_type=job_listing&p=31309','Illinois Nutrient Research & Education Council','Executive Director','Springfield, Illinois, United States',NULL,'https://greenjobs.greenjobsearch.org/jobs/executive-director-204/','The mission of the Illinois Nutrient Research & Education Council (NREC) is to fund science-based research and educational programs that optimize nutrient use efficiency, improve soil fertility, and protect water quality. Created to support the state’s Nutrient Loss Reduction Strategy, NREC connects agriculture with environmental stewardship to ensure farmers can maximize yields while minimizing environmental […] The post Executive Director appeared first on Green Jobs Board - greenjobsearch.org .','Mon, 08 Jun 2026 03:24:01 +0000','2026-06-08T12:03:31+00:00','2026-06-24T10:25:44+00:00',1,0.0,'no_keyword_hits','not_reviewed',NULL);
INSERT INTO postings VALUES(102,'greenjobs','https://greenjobs.greenjobsearch.org/?post_type=job_listing&p=31303','Spitfire Strategies','Vice President','California, United States',NULL,'https://greenjobs.greenjobsearch.org/jobs/vice-president-2/','Spitfire seeks an imaginative and passionate senior leader with experience working on environmental issues that understands the fast-paced client environment, welcomes complex communication challenges, and believes in the value of relationships. This position is based in California. Previous firm experience is required. About Spitfire Spitfire is recognized as a national leader in public interest communication […] The post Vice President appeared first on Green Jobs Board - greenjobsearch.org .','Sat, 06 Jun 2026 18:26:21 +0000','2026-06-08T12:03:31+00:00','2026-06-24T10:25:44+00:00',1,0.0,'no_keyword_hits','not_reviewed',NULL);
INSERT INTO postings VALUES(103,'greenjobs','https://greenjobs.greenjobsearch.org/?post_type=job_listing&p=31297','The Wilderness Society','California Conservation Manager (NorCal)','California, United States',NULL,'https://greenjobs.greenjobsearch.org/jobs/california-conservation-manager-norcal/','About The Wilderness Society The Wilderness Society is a national conservation organization dedicated to protecting America’s wild places since 1935. Our mission is to unite people to protect America’s wild places. Through science, advocacy and partnerships with communities and policymakers, we champion the protection of wilderness, national parks, forests, and other public lands that provide clean […] The post California Conservation Manager (NorCal) appeared first on Green Jobs Board - greenjobsearch.org .','Fri, 05 Jun 2026 17:21:19 +0000','2026-06-08T12:03:31+00:00','2026-06-24T10:25:44+00:00',1,0.0,'no_keyword_hits','not_reviewed',NULL);
INSERT INTO postings VALUES(104,'greenjobs','https://greenjobs.greenjobsearch.org/?post_type=job_listing&p=31290','The Wilderness Society','Alaska State Director','Anchorage, Alaska, United States',NULL,'https://greenjobs.greenjobsearch.org/jobs/alaska-state-director-3/','About The Wilderness Society The Wilderness Society is a national conservation organization dedicated to protecting America’s wild places since 1935. Our mission is to unite people to protect America’s wild places. Through science, advocacy and partnerships with communities and policymakers, we champion the protection of wilderness, national parks, forests, and other public lands that provide clean […] The post Alaska State Director appeared first on Green Jobs Board - greenjobsearch.org .','Fri, 05 Jun 2026 17:13:52 +0000','2026-06-08T12:03:31+00:00','2026-06-22T12:53:55+00:00',1,0.0,'no_keyword_hits','not_reviewed',NULL);
INSERT INTO postings VALUES(121,'greenjobs','https://greenjobs.greenjobsearch.org/?post_type=job_listing&p=31425','Pathways','Customer Success Manager','New York, New York, United States',NULL,'https://greenjobs.greenjobsearch.org/jobs/customer-success-manager/','About the job We’re building something big. We want you in early. Pathways is a fast-growing climate tech startup helping construction materials manufacturers decarbonize the built environment. Our platform makes it easier for manufacturers to collect, report, and act on environmental data. We’ve landed industry-leading customers and we’re scaling fast. Now we’re expanding our Customer […] The post Customer Success Manager appeared first on Green Jobs Board - greenjobsearch.org .','Tue, 16 Jun 2026 19:18:28 +0000','2026-06-17T11:54:35+00:00','2026-06-24T10:25:44+00:00',1,0.0,'no_keyword_hits','not_reviewed',NULL);
INSERT INTO postings VALUES(122,'greenjobs','https://greenjobs.greenjobsearch.org/?post_type=job_listing&p=31412','Bellevue Botanical Garden Society','Executive Director','Bellevue, Washington, United States',NULL,'https://greenjobs.greenjobsearch.org/jobs/executive-director-206/','Executive Director Bellevue Botanical Garden Society Salary: $120,000 – $140,000 annually, DOE The Opportunity Step into a leadership role where you can see your work literally bloom. As Executive Director (ED) of the Bellevue Botanical Garden Society (BBGS), you’ll provide programming and fundraising in support of one of the nation’s premier botanical gardens that […] The post Executive Director appeared first on Green Jobs Board - greenjobsearch.org .','Tue, 16 Jun 2026 00:04:41 +0000','2026-06-17T11:54:35+00:00','2026-06-24T10:25:44+00:00',1,0.0,'no_keyword_hits','not_reviewed',NULL);
INSERT INTO postings VALUES(123,'greenjobs','https://greenjobs.greenjobsearch.org/?post_type=job_listing&p=31382','Philadelphia Ship Preservation Guild','Program and Education Manager','Philadelphia, Pennsylvania, United States',NULL,'https://greenjobs.greenjobsearch.org/jobs/program-and-education-manager/','Organization Description The Philadelphia Ship Preservation Guild (PSPG) provides educational and community-building programs that connect communities with maritime heritage through the stewardship of historic ships. This includes the barkentine Gazela Primeiro, the tugboat Jupiter, and the barge Poplar, which serve as living, interactive museums and classrooms along the Delaware River waterfront, offering immersive learning experiences […] The post Program and Education Manager appeared first on Green Jobs Board - greenjobsearch.org .','Mon, 15 Jun 2026 20:58:19 +0000','2026-06-17T11:54:35+00:00','2026-06-24T10:25:44+00:00',1,0.0,'no_keyword_hits','not_reviewed',NULL);
INSERT INTO postings VALUES(124,'greenjobs','https://greenjobs.greenjobsearch.org/?post_type=job_listing&p=31406','Land Trust Alliance','New York Senior Program Manager','New York, United States',NULL,'https://greenjobs.greenjobsearch.org/jobs/new-york-senior-program-manager/','Location: Candidates must reside in New York – preferably a central location near Albany Overview The Land Trust Alliance is the voice of the land trust community. As the national leader in policy, standards and education, we work passionately to support land trusts across America so they can save more land and better serve their […] The post New York Senior Program Manager appeared first on Green Jobs Board - greenjobsearch.org .','Mon, 15 Jun 2026 20:39:54 +0000','2026-06-17T11:54:35+00:00','2026-06-24T10:25:44+00:00',1,0.0,'no_keyword_hits','not_reviewed',NULL);
INSERT INTO postings VALUES(125,'greenjobs','https://greenjobs.greenjobsearch.org/?post_type=job_listing&p=31402','Farmer Grant - University of Vermont','SARE Grant Program Admin – Farmer Grant','Burlington, Vermont, United States',NULL,'https://greenjobs.greenjobsearch.org/jobs/sare-grant-program-admin-farmer-grant/','SARE Grant Program Admin – Farmer Grant Posting Summary About Northeast SARE: The Northeast Sustainable Agriculture Research and Education (SARE) Program is one of four regional SARE programs funded by the USDA National Institute of Food and Agriculture and administered by the University of Vermont. Northeast SARE offers grants and education to farmers, educators, service […] The post SARE Grant Program Admin – Farmer Grant appeared first on Green Jobs Board - greenjobsearch.org .','Mon, 15 Jun 2026 20:14:08 +0000','2026-06-17T11:54:35+00:00','2026-06-24T10:25:44+00:00',1,0.0,'no_keyword_hits','not_reviewed',NULL);
INSERT INTO postings VALUES(126,'greenjobs','https://greenjobs.greenjobsearch.org/?post_type=job_listing&p=31378','Columbia Land Trust','Executive Director','Vancouver, Washington, United States',NULL,'https://greenjobs.greenjobsearch.org/jobs/executive-director-205/','POSITION OVERVIEW AND RESPONSIBILITIES The Executive Director will provide organizational leadership by guiding strategy, supporting a talented and empowered staff team, nurturing strong board relations, stewarding donor and community relationships, and serving as the primary public face and voice of Columbia Land Trust across the Columbia River region and beyond. The position calls for a […] The post Executive Director appeared first on Green Jobs Board - greenjobsearch.org .','Fri, 12 Jun 2026 19:08:47 +0000','2026-06-17T11:54:35+00:00','2026-06-24T10:25:44+00:00',1,0.0,'no_keyword_hits','not_reviewed',NULL);
INSERT INTO postings VALUES(127,'greenjobs','https://greenjobs.greenjobsearch.org/?post_type=job_listing&p=31372','Montgomery County, MD Government','Manager II (Community Choice Energy Aggregation Program), Grade M2','Wheaton-Glenmont, Maryland, United States',NULL,'https://greenjobs.greenjobsearch.org/jobs/manager-ii-community-choice-energy-aggregation-program-grade-m2/','Manager II (Community Choice Energy Aggregation Program), Grade M2 Montgomery County Government Department of Environmental Protection 2425 Reedie Drive, Wheaton, Maryland 20902 Salary Range: $113,715 to $200,829 NOTE: This is a 2-year term position that expires on 6/30/2028. Continued employment in this position is contingent upon renewal of term. WHO WE ARE The Department of […] The post Manager II (Community Choice Energy Aggregation Program), Grade M2 appeared first on Green Jobs Board - greenjobsearch.org .','Fri, 12 Jun 2026 15:38:01 +0000','2026-06-17T11:54:35+00:00','2026-06-24T10:25:44+00:00',1,0.0,'no_keyword_hits','not_reviewed',NULL);
INSERT INTO postings VALUES(128,'greenjobs','https://greenjobs.greenjobsearch.org/?post_type=job_listing&p=31366','Boundless Impact Research & Analytics','Research Associate','New York, New York, United States',NULL,'https://greenjobs.greenjobsearch.org/jobs/research-associate-7/','Research Associate Job Description Boundless Impact Research & Analytics (Boundless) is seeking a full-time Research Associate intern with environmental analysis and research experience, and an interest in and aptitude for applying Life Cycle Assessment (LCA) and Techno-Economic Analysis (TEA) to clean energy and other advanced technologies. The Research Associate will support the Boundless research team […] The post Research Associate appeared first on Green Jobs Board - greenjobsearch.org .','Thu, 11 Jun 2026 21:22:40 +0000','2026-06-17T11:54:35+00:00','2026-06-24T10:25:44+00:00',1,0.0,'no_keyword_hits','not_reviewed',NULL);
INSERT INTO postings VALUES(129,'greenjobs','https://greenjobs.greenjobsearch.org/?post_type=job_listing&p=31362','New Mexico Land Conservancy','Land Conservation Manager','Santa Fe, New Mexico, United States',NULL,'https://greenjobs.greenjobsearch.org/jobs/land-conservation-manager-2/','Join Our Team The New Mexico Land Conservancy (NMLC) is a non-profit land trust based in Santa Fe, New Mexico, dedicated to preserving New Mexico’s unique natural, cultural and agricultural heritage by helping people conserve the land they love. NMLC is one of the leaders in land conservation in the Southwest and, since 2002, has […] The post Land Conservation Manager appeared first on Green Jobs Board - greenjobsearch.org .','Thu, 11 Jun 2026 13:53:45 +0000','2026-06-17T11:54:35+00:00','2026-06-24T10:25:44+00:00',1,0.0,'no_keyword_hits','not_reviewed',NULL);
INSERT INTO postings VALUES(130,'greenjobs','https://greenjobs.greenjobsearch.org/?post_type=job_listing&p=31359','Clark County Department of Environment and Sustainability','Air Quality Modeler','Las Vegas, Nevada, United States',NULL,'https://greenjobs.greenjobsearch.org/jobs/air-quality-modeler-2/','ABOUT THE POSITION The Clark County Department of Environment and Sustainability is seeking qualified candidates to apply for the Air Quality Modeler This Air Quality Modeler position falls within the department’s Planning section. This role will work among professional and technical support staff involved with air quality planning. This team member will utilize emissions inventories, […] The post Air Quality Modeler appeared first on Green Jobs Board - greenjobsearch.org .','Wed, 10 Jun 2026 21:31:30 +0000','2026-06-17T11:54:35+00:00','2026-06-24T10:25:44+00:00',1,0.0,'no_keyword_hits','not_reviewed',NULL);
INSERT INTO postings VALUES(131,'greenjobs','https://greenjobs.greenjobsearch.org/?post_type=job_listing&p=31350','Hampton Roads Planning District Commission','Environmental Outreach Specialist','Chesapeake, Virginia, United States',NULL,'https://greenjobs.greenjobsearch.org/jobs/environmental-outreach-specialist/','HRPDC is seeking applicants for a full-time Environmental Outreach Specialist. As part of the Environmental Education team, the successful candidate will support the development, coordination and promotion of regional environmental education and outreach initiatives across Hampton Roads. The Environmental Outreach Specialist assists with community engagement, communications, program administration, and event coordination that advance regional environmental […] The post Environmental Outreach Specialist appeared first on Green Jobs Board - greenjobsearch.org .','Wed, 10 Jun 2026 15:17:13 +0000','2026-06-17T11:54:35+00:00','2026-06-24T10:25:44+00:00',1,0.0,'no_keyword_hits','not_reviewed',NULL);
INSERT INTO postings VALUES(132,'greenjobs','https://greenjobs.greenjobsearch.org/?post_type=job_listing&p=31346','Institute for Market Transformation','David B. Goldstein Fellow','Anywhere',NULL,'https://greenjobs.greenjobsearch.org/jobs/david-b-goldstein-fellow/','About the Fellowship Inspired by the legacy of IMT’s founding chair, Dr. David B. Goldstein, the Fellowship supports recent undergraduate students as they transition into the clean energy workforce. The program provides the Fellow with valuable leadership skills and experience in research and policy work focused on accelerating the decarbonization of buildings while benefitting communities, […] The post David B. Goldstein Fellow appeared first on Green Jobs Board - greenjobsearch.org .','Wed, 10 Jun 2026 15:10:28 +0000','2026-06-17T11:54:35+00:00','2026-06-24T10:25:44+00:00',1,0.0,'no_keyword_hits','not_reviewed',NULL);
INSERT INTO postings VALUES(133,'greenjobs','https://greenjobs.greenjobsearch.org/?post_type=job_listing&p=31336','Los Angeles Community College District','Arboretum and Botanical Gardens Manager','Los Angeles, California, United States',NULL,'https://greenjobs.greenjobsearch.org/jobs/arboretum-and-botanical-gardens-manager/','Arboretum and Botanical Gardens Manager Date Opened: 6/8/2026 Filing Deadline: 7/3/2026 Location: Los Angeles Pierce College Salary: $7,636.00 – $9,459.00/mo; $91,632.00 – $113,508.00/yr (based on a full-time, 12-month position) Job Type: Open & Promotional (Dual) Definition Plans, supervises, coordinates, and participates in the business operations and maintenance of the Arboretum and Botanical Gardens at Los […] The post Arboretum and Botanical Gardens Manager appeared first on Green Jobs Board - greenjobsearch.org .','Tue, 09 Jun 2026 15:58:50 +0000','2026-06-17T11:54:35+00:00','2026-06-24T10:25:44+00:00',1,0.0,'no_keyword_hits','not_reviewed',NULL);
INSERT INTO postings VALUES(134,'greenjobs','https://greenjobs.greenjobsearch.org/?post_type=job_listing&p=31332','Part-time Contractor - Greener By Default','UK Healthcare Manager – Part-time Contractor','United Kingdom',NULL,'https://greenjobs.greenjobsearch.org/jobs/uk-healthcare-manager-part-time-contractor/','UK Healthcare Manager – Part-time Contractor Job Description PLEASE FILL OUT THIS FORM BY 26 JUNE, 2026 IN ORDER TO APPLY. At Greener by Default, you will be working towards the ambitious goal of completely transforming institutional foodservice – and the food system as a whole – by making plant-forward menus the norm and plant-based […] The post UK Healthcare Manager – Part-time Contractor appeared first on Green Jobs Board - greenjobsearch.org .','Tue, 09 Jun 2026 14:42:11 +0000','2026-06-17T11:54:35+00:00','2026-06-24T10:25:44+00:00',1,0.0,'no_keyword_hits','not_reviewed',NULL);
INSERT INTO postings VALUES(135,'greenjobs','https://greenjobs.greenjobsearch.org/?post_type=job_listing&p=31328','Greener By Default','US Healthcare Manager','Anywhere',NULL,'https://greenjobs.greenjobsearch.org/jobs/us-healthcare-manager/','US Healthcare Manager PLEASE FILL OUT THIS FORM BY JUNE 26, 2026 TO APPLY. At Greener by Default, you will be working towards the ambitious goal of completely transforming institutional foodservice – and the food system as a whole – by making plant-forward menus the norm and plant-based options the default. We recognize that the […] The post US Healthcare Manager appeared first on Green Jobs Board - greenjobsearch.org .','Tue, 09 Jun 2026 14:36:19 +0000','2026-06-17T11:54:35+00:00','2026-06-24T10:25:44+00:00',1,0.0,'no_keyword_hits','not_reviewed',NULL);
INSERT INTO postings VALUES(136,'greenjobs','https://greenjobs.greenjobsearch.org/?post_type=job_listing&p=31315','Land Trust Alliance','ARMS National Coordinating Attorney','Anywhere',NULL,'https://greenjobs.greenjobsearch.org/jobs/arms-national-coordinating-attorney/','Overview The Land Trust Alliance is the voice of the land trust community. As the national leader in policy, standards and education, we work passionately to support land trusts across America so they can save more land and better serve their communities. Our natural places and working lands are a lifeline to clean air, water, […] The post ARMS National Coordinating Attorney appeared first on Green Jobs Board - greenjobsearch.org .','Mon, 08 Jun 2026 18:56:59 +0000','2026-06-17T11:54:35+00:00','2026-06-24T10:25:44+00:00',1,0.0,'FILTERED: blacklist: attorney','not_reviewed',NULL);
INSERT INTO postings VALUES(181,'greenjobs','https://greenjobs.greenjobsearch.org/?post_type=job_listing&p=31453','New Jersey League of Conservation Voters','Executive Director and Chief Executive Officer','Trenton, New Jersey, United States',NULL,'https://greenjobs.greenjobsearch.org/jobs/executive-director-and-chief-executive-officer/','Executive Director and Chief Executive Officer New Jersey League of Conservation Voters Trenton, New Jersey People. Planet. Politics. The New Jersey League of Conservation Voters (New Jersey LCV), New Jersey’s statewide political voice for the environment, seeks a strategic and mission-driven Executive Director and Chief Executive Officer to lead this dynamic family of […] The post Executive Director and Chief Executive Officer appeared first on Green Jobs Board - greenjobsearch.org .','Tue, 23 Jun 2026 16:05:32 +0000','2026-06-24T10:25:44+00:00','2026-06-24T10:25:44+00:00',1,0.0,'no_keyword_hits','not_reviewed',NULL);
CREATE TABLE applications (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    posting_id      INTEGER NOT NULL,

    -- Pipeline status
    status          TEXT NOT NULL DEFAULT 'new',
        -- valid values: 'new', 'reviewing', 'tailored', 'submitted',
        --               'interviewing', 'offered', 'rejected', 'withdrawn', 'closed'

    -- Tracking
    submitted_at    TEXT,                   -- ISO-8601 UTC, when she actually applied
    resume_path     TEXT,                   -- path to tailored resume .docx, if any
    cover_letter_path TEXT,                 -- path to cover letter .docx, if any
    notes           TEXT,                   -- freeform notes from her

    -- JD capture (D18 — snapshot at Apply time, edited via modal)
    jd_snapshot     TEXT,                   -- full JD text as the user edited/confirmed it
    tailored_notes  TEXT,                   -- paste-back from the Claude tailoring chat

    -- Housekeeping
    created_at      TEXT NOT NULL,
    updated_at      TEXT NOT NULL,

    FOREIGN KEY (posting_id) REFERENCES postings(id)
);
CREATE TABLE source_log (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    source          TEXT NOT NULL,          -- 'greenhouse', 'lever', etc.
    company         TEXT,                   -- NULL when the run hits many companies
    run_at          TEXT NOT NULL,          -- ISO-8601 UTC, when scraper started
    status          TEXT NOT NULL,          -- 'success', 'error', 'skipped'
    postings_found  INTEGER NOT NULL DEFAULT 0,
    postings_new    INTEGER NOT NULL DEFAULT 0,
    postings_updated INTEGER NOT NULL DEFAULT 0,
    error_message   TEXT,
    duration_ms     INTEGER
);
INSERT INTO source_log VALUES(1,'greenhouse','World Resources Institute (WRI)','2026-05-27T10:58:43+00:00','error',0,0,0,'HTTP 404: {"status":404,"error":"Job board not found"}',162);
INSERT INTO source_log VALUES(2,'greenhouse','Bain & Company','2026-05-27T10:58:44+00:00','error',0,0,0,'HTTP 404: {"status":404,"error":"Job board not found"}',73);
INSERT INTO source_log VALUES(3,'greenhouse','Analysis Group','2026-05-27T10:58:45+00:00','error',0,0,0,'HTTP 404: {"status":404,"error":"Job board not found"}',119);
INSERT INTO source_log VALUES(4,'greenhouse','Atlantic Council','2026-05-27T10:58:46+00:00','error',0,0,0,'HTTP 404: {"status":404,"error":"Job board not found"}',102);
INSERT INTO source_log VALUES(5,'greenhouse','Center for American Progress (CAP)','2026-05-27T10:58:47+00:00','error',0,0,0,'HTTP 404: {"status":404,"error":"Job board not found"}',71);
INSERT INTO source_log VALUES(6,'greenhouse','Results for Development (R4D)','2026-05-27T10:58:49+00:00','error',0,0,0,'HTTP 404: {"status":404,"error":"Job board not found"}',79);
INSERT INTO source_log VALUES(7,'greenhouse','Rocky Mountain Institute (RMI)','2026-05-27T10:58:50+00:00','error',0,0,0,'HTTP 404: {"status":404,"error":"Job board not found"}',76);
INSERT INTO source_log VALUES(8,'greenhouse','Clean Air Task Force (CATF)','2026-05-27T10:58:51+00:00','error',0,0,0,'HTTP 404: {"status":404,"error":"Job board not found"}',115);
INSERT INTO source_log VALUES(9,'greenhouse','Center for Climate and Energy Solutions (C2ES)','2026-05-27T10:58:52+00:00','error',0,0,0,'HTTP 404: {"status":404,"error":"Job board not found"}',134);
INSERT INTO source_log VALUES(10,'greenhouse','Ceres','2026-05-27T10:58:53+00:00','error',0,0,0,'HTTP 404: {"status":404,"error":"Job board not found"}',62);
INSERT INTO source_log VALUES(11,'greenhouse','BlueGreen Alliance','2026-05-27T10:58:54+00:00','error',0,0,0,'HTTP 404: {"status":404,"error":"Job board not found"}',271);
INSERT INTO source_log VALUES(12,'greenhouse','Bipartisan Policy Center','2026-05-27T10:58:55+00:00','error',0,0,0,'HTTP 404: {"status":404,"error":"Job board not found"}',72);
INSERT INTO source_log VALUES(13,'greenhouse','New America Foundation','2026-05-27T10:58:56+00:00','error',0,0,0,'HTTP 404: {"status":404,"error":"Job board not found"}',85);
INSERT INTO source_log VALUES(14,'greenhouse','Rockefeller Foundation','2026-05-27T10:58:57+00:00','error',0,0,0,'HTTP 404: {"status":404,"error":"Job board not found"}',66);
INSERT INTO source_log VALUES(15,'greenhouse','Bloomberg Philanthropies','2026-05-27T10:58:59+00:00','error',0,0,0,'HTTP 404: {"status":404,"error":"Job board not found"}',72);
INSERT INTO source_log VALUES(16,'greenhouse','Hewlett Foundation','2026-05-27T10:59:00+00:00','error',0,0,0,'HTTP 404: {"status":404,"error":"Job board not found"}',81);
INSERT INTO source_log VALUES(17,'greenhouse','IREX','2026-05-27T10:59:01+00:00','error',0,0,0,'HTTP 404: {"status":404,"error":"Job board not found"}',71);
INSERT INTO source_log VALUES(18,'greenhouse','Freedom House','2026-05-27T10:59:02+00:00','error',0,0,0,'HTTP 404: {"status":404,"error":"Job board not found"}',270);
INSERT INTO source_log VALUES(19,'greenjobs','GreenJobs.com (aggregated)','2026-05-27T10:59:02+00:00','success',20,20,0,NULL,17475);
INSERT INTO source_log VALUES(20,'neogov','Fairfax County Government','2026-05-27T10:59:20+00:00','error',0,0,0,'HTTP 400: Bad Request',407);
INSERT INTO source_log VALUES(21,'neogov','Arlington County Government','2026-05-27T10:59:22+00:00','error',0,0,0,'HTTP 400: Bad Request',309);
INSERT INTO source_log VALUES(22,'neogov','Montgomery County Government (MD)','2026-05-27T10:59:23+00:00','error',0,0,0,'HTTP 400: Bad Request',284);
INSERT INTO source_log VALUES(23,'neogov','Prince George''s County (MD)','2026-05-27T10:59:24+00:00','error',0,0,0,'HTTP 400: Bad Request',381);
INSERT INTO source_log VALUES(24,'neogov','City of Alexandria (VA)','2026-05-27T10:59:26+00:00','error',0,0,0,'HTTP 400: Bad Request',318);
INSERT INTO source_log VALUES(25,'neogov','Falls Church City (VA)','2026-05-27T10:59:27+00:00','error',0,0,0,'request failed: HTTPSConnectionPool(host=''www.governmentjobs.com'', port=443): Max retries exceeded with url: /SearchEngine/JobsFeed?agency= (Caused by ConnectTimeoutError(<HTTPSConnection(host=''www.governmentjobs.com'', port=443) at 0x7f96946ab010>, ''Connection to www.governmentjobs.com timed out. (connect timeout=30)''))',30034);
INSERT INTO source_log VALUES(26,'neogov','City of Rockville (MD)','2026-05-27T10:59:58+00:00','error',0,0,0,'request failed: HTTPSConnectionPool(host=''www.governmentjobs.com'', port=443): Max retries exceeded with url: /SearchEngine/JobsFeed?agency= (Caused by ConnectTimeoutError(<HTTPSConnection(host=''www.governmentjobs.com'', port=443) at 0x7f96946b4a90>, ''Connection to www.governmentjobs.com timed out. (connect timeout=30)''))',30037);
INSERT INTO source_log VALUES(27,'neogov','Loudoun County (VA)','2026-05-27T11:00:29+00:00','error',0,0,0,'request failed: HTTPSConnectionPool(host=''www.governmentjobs.com'', port=443): Max retries exceeded with url: /SearchEngine/JobsFeed?agency= (Caused by ConnectTimeoutError(<HTTPSConnection(host=''www.governmentjobs.com'', port=443) at 0x7f96946a3150>, ''Connection to www.governmentjobs.com timed out. (connect timeout=30)''))',30034);
INSERT INTO source_log VALUES(28,'neogov','Prince William County (VA)','2026-05-27T11:01:00+00:00','error',0,0,0,'request failed: HTTPSConnectionPool(host=''www.governmentjobs.com'', port=443): Max retries exceeded with url: /SearchEngine/JobsFeed?agency= (Caused by ConnectTimeoutError(<HTTPSConnection(host=''www.governmentjobs.com'', port=443) at 0x7f96946b6890>, ''Connection to www.governmentjobs.com timed out. (connect timeout=30)''))',30018);
INSERT INTO source_log VALUES(29,'greenhouse','World Resources Institute (WRI)','2026-05-29T10:51:28+00:00','error',0,0,0,'HTTP 404: {"status":404,"error":"Job board not found"}',164);
INSERT INTO source_log VALUES(30,'greenhouse','Bain & Company','2026-05-29T10:51:29+00:00','error',0,0,0,'HTTP 404: {"status":404,"error":"Job board not found"}',526);
INSERT INTO source_log VALUES(31,'greenhouse','Analysis Group','2026-05-29T10:51:31+00:00','error',0,0,0,'HTTP 404: {"status":404,"error":"Job board not found"}',114);
INSERT INTO source_log VALUES(32,'greenhouse','Atlantic Council','2026-05-29T10:51:32+00:00','error',0,0,0,'HTTP 404: {"status":404,"error":"Job board not found"}',132);
INSERT INTO source_log VALUES(33,'greenhouse','Center for American Progress (CAP)','2026-05-29T10:51:33+00:00','error',0,0,0,'HTTP 404: {"status":404,"error":"Job board not found"}',80);
INSERT INTO source_log VALUES(34,'greenhouse','Results for Development (R4D)','2026-05-29T10:51:34+00:00','error',0,0,0,'HTTP 404: {"status":404,"error":"Job board not found"}',108);
INSERT INTO source_log VALUES(35,'greenhouse','Rocky Mountain Institute (RMI)','2026-05-29T10:51:35+00:00','error',0,0,0,'HTTP 404: {"status":404,"error":"Job board not found"}',92);
INSERT INTO source_log VALUES(36,'greenhouse','Clean Air Task Force (CATF)','2026-05-29T10:51:36+00:00','error',0,0,0,'HTTP 404: {"status":404,"error":"Job board not found"}',90);
INSERT INTO source_log VALUES(37,'greenhouse','Center for Climate and Energy Solutions (C2ES)','2026-05-29T10:51:37+00:00','error',0,0,0,'HTTP 404: {"status":404,"error":"Job board not found"}',63);
INSERT INTO source_log VALUES(38,'greenhouse','Ceres','2026-05-29T10:51:38+00:00','error',0,0,0,'HTTP 404: {"status":404,"error":"Job board not found"}',109);
INSERT INTO source_log VALUES(39,'greenhouse','BlueGreen Alliance','2026-05-29T10:51:39+00:00','error',0,0,0,'HTTP 404: {"status":404,"error":"Job board not found"}',72);
INSERT INTO source_log VALUES(40,'greenhouse','Bipartisan Policy Center','2026-05-29T10:51:40+00:00','error',0,0,0,'HTTP 404: {"status":404,"error":"Job board not found"}',76);
INSERT INTO source_log VALUES(41,'greenhouse','New America Foundation','2026-05-29T10:51:41+00:00','error',0,0,0,'HTTP 404: {"status":404,"error":"Job board not found"}',129);
INSERT INTO source_log VALUES(42,'greenhouse','Rockefeller Foundation','2026-05-29T10:51:43+00:00','error',0,0,0,'HTTP 404: {"status":404,"error":"Job board not found"}',84);
INSERT INTO source_log VALUES(43,'greenhouse','Bloomberg Philanthropies','2026-05-29T10:51:44+00:00','error',0,0,0,'HTTP 404: {"status":404,"error":"Job board not found"}',57);
INSERT INTO source_log VALUES(44,'greenhouse','Hewlett Foundation','2026-05-29T10:51:45+00:00','error',0,0,0,'HTTP 404: {"status":404,"error":"Job board not found"}',93);
INSERT INTO source_log VALUES(45,'greenhouse','IREX','2026-05-29T10:51:46+00:00','error',0,0,0,'HTTP 404: {"status":404,"error":"Job board not found"}',94);
INSERT INTO source_log VALUES(46,'greenhouse','Freedom House','2026-05-29T10:51:47+00:00','error',0,0,0,'HTTP 404: {"status":404,"error":"Job board not found"}',60);
INSERT INTO source_log VALUES(47,'greenjobs','GreenJobs.com (aggregated)','2026-05-29T10:51:47+00:00','success',20,2,18,NULL,14546);
INSERT INTO source_log VALUES(48,'neogov','Fairfax County Government','2026-05-29T10:52:02+00:00','error',0,0,0,'HTTP 400: Bad Request',478);
INSERT INTO source_log VALUES(49,'neogov','Arlington County Government','2026-05-29T10:52:04+00:00','error',0,0,0,'HTTP 400: Bad Request',392);
INSERT INTO source_log VALUES(50,'neogov','Montgomery County Government (MD)','2026-05-29T10:52:05+00:00','error',0,0,0,'HTTP 400: Bad Request',390);
INSERT INTO source_log VALUES(51,'neogov','Prince George''s County (MD)','2026-05-29T10:52:06+00:00','error',0,0,0,'HTTP 400: Bad Request',404);
INSERT INTO source_log VALUES(52,'neogov','City of Alexandria (VA)','2026-05-29T10:52:08+00:00','error',0,0,0,'HTTP 400: Bad Request',418);
INSERT INTO source_log VALUES(53,'neogov','Falls Church City (VA)','2026-05-29T10:52:09+00:00','error',0,0,0,'HTTP 400: Bad Request',418);
INSERT INTO source_log VALUES(54,'neogov','City of Rockville (MD)','2026-05-29T10:52:11+00:00','error',0,0,0,'request failed: HTTPSConnectionPool(host=''www.governmentjobs.com'', port=443): Max retries exceeded with url: /SearchEngine/JobsFeed?agency= (Caused by ConnectTimeoutError(<HTTPSConnection(host=''www.governmentjobs.com'', port=443) at 0x7f337401b910>, ''Connection to www.governmentjobs.com timed out. (connect timeout=30)''))',30047);
INSERT INTO source_log VALUES(55,'neogov','Loudoun County (VA)','2026-05-29T10:52:42+00:00','error',0,0,0,'request failed: HTTPSConnectionPool(host=''www.governmentjobs.com'', port=443): Max retries exceeded with url: /SearchEngine/JobsFeed?agency= (Caused by ConnectTimeoutError(<HTTPSConnection(host=''www.governmentjobs.com'', port=443) at 0x7f3374024650>, ''Connection to www.governmentjobs.com timed out. (connect timeout=30)''))',30034);
INSERT INTO source_log VALUES(56,'neogov','Prince William County (VA)','2026-05-29T10:53:13+00:00','error',0,0,0,'request failed: HTTPSConnectionPool(host=''www.governmentjobs.com'', port=443): Max retries exceeded with url: /SearchEngine/JobsFeed?agency= (Caused by ConnectTimeoutError(<HTTPSConnection(host=''www.governmentjobs.com'', port=443) at 0x7f337400ef50>, ''Connection to www.governmentjobs.com timed out. (connect timeout=30)''))',30063);
INSERT INTO source_log VALUES(57,'greenhouse','World Resources Institute (WRI)','2026-06-01T12:42:53+00:00','error',0,0,0,'HTTP 404: {"status":404,"error":"Job board not found"}',89);
INSERT INTO source_log VALUES(58,'greenhouse','Bain & Company','2026-06-01T12:42:54+00:00','error',0,0,0,'HTTP 404: {"status":404,"error":"Job board not found"}',79);
INSERT INTO source_log VALUES(59,'greenhouse','Analysis Group','2026-06-01T12:42:55+00:00','error',0,0,0,'HTTP 404: {"status":404,"error":"Job board not found"}',76);
INSERT INTO source_log VALUES(60,'greenhouse','Atlantic Council','2026-06-01T12:42:56+00:00','error',0,0,0,'HTTP 404: {"status":404,"error":"Job board not found"}',53);
INSERT INTO source_log VALUES(61,'greenhouse','Center for American Progress (CAP)','2026-06-01T12:42:57+00:00','error',0,0,0,'HTTP 404: {"status":404,"error":"Job board not found"}',61);
INSERT INTO source_log VALUES(62,'greenhouse','Results for Development (R4D)','2026-06-01T12:42:58+00:00','error',0,0,0,'HTTP 404: {"status":404,"error":"Job board not found"}',119);
INSERT INTO source_log VALUES(63,'greenhouse','Rocky Mountain Institute (RMI)','2026-06-01T12:42:59+00:00','error',0,0,0,'HTTP 404: {"status":404,"error":"Job board not found"}',87);
INSERT INTO source_log VALUES(64,'greenhouse','Clean Air Task Force (CATF)','2026-06-01T12:43:00+00:00','error',0,0,0,'HTTP 404: {"status":404,"error":"Job board not found"}',49);
INSERT INTO source_log VALUES(65,'greenhouse','Center for Climate and Energy Solutions (C2ES)','2026-06-01T12:43:01+00:00','error',0,0,0,'HTTP 404: {"status":404,"error":"Job board not found"}',48);
INSERT INTO source_log VALUES(66,'greenhouse','Ceres','2026-06-01T12:43:02+00:00','error',0,0,0,'HTTP 404: {"status":404,"error":"Job board not found"}',65);
INSERT INTO source_log VALUES(67,'greenhouse','BlueGreen Alliance','2026-06-01T12:43:04+00:00','error',0,0,0,'HTTP 404: {"status":404,"error":"Job board not found"}',48);
INSERT INTO source_log VALUES(68,'greenhouse','Bipartisan Policy Center','2026-06-01T12:43:05+00:00','error',0,0,0,'HTTP 404: {"status":404,"error":"Job board not found"}',69);
INSERT INTO source_log VALUES(69,'greenhouse','New America Foundation','2026-06-01T12:43:06+00:00','error',0,0,0,'HTTP 404: {"status":404,"error":"Job board not found"}',106);
INSERT INTO source_log VALUES(70,'greenhouse','Rockefeller Foundation','2026-06-01T12:43:07+00:00','error',0,0,0,'HTTP 404: {"status":404,"error":"Job board not found"}',62);
INSERT INTO source_log VALUES(71,'greenhouse','Bloomberg Philanthropies','2026-06-01T12:43:08+00:00','error',0,0,0,'HTTP 404: {"status":404,"error":"Job board not found"}',48);
INSERT INTO source_log VALUES(72,'greenhouse','Hewlett Foundation','2026-06-01T12:43:09+00:00','error',0,0,0,'HTTP 404: {"status":404,"error":"Job board not found"}',59);
INSERT INTO source_log VALUES(73,'greenhouse','IREX','2026-06-01T12:43:10+00:00','error',0,0,0,'HTTP 404: {"status":404,"error":"Job board not found"}',123);
INSERT INTO source_log VALUES(74,'greenhouse','Freedom House','2026-06-01T12:43:11+00:00','error',0,0,0,'HTTP 404: {"status":404,"error":"Job board not found"}',50);
INSERT INTO source_log VALUES(75,'greenjobs','GreenJobs.com (aggregated)','2026-06-01T12:43:11+00:00','success',20,2,18,NULL,17713);
INSERT INTO source_log VALUES(76,'neogov','Fairfax County Government','2026-06-01T12:43:29+00:00','error',0,0,0,'HTTP 400: Bad Request',387);
INSERT INTO source_log VALUES(77,'neogov','Arlington County Government','2026-06-01T12:43:31+00:00','error',0,0,0,'HTTP 400: Bad Request',344);
INSERT INTO source_log VALUES(78,'neogov','Montgomery County Government (MD)','2026-06-01T12:43:32+00:00','error',0,0,0,'HTTP 400: Bad Request',421);
INSERT INTO source_log VALUES(79,'neogov','Prince George''s County (MD)','2026-06-01T12:43:34+00:00','error',0,0,0,'HTTP 400: Bad Request',420);
INSERT INTO source_log VALUES(80,'neogov','City of Alexandria (VA)','2026-06-01T12:43:35+00:00','error',0,0,0,'HTTP 400: Bad Request',354);
INSERT INTO source_log VALUES(81,'neogov','Falls Church City (VA)','2026-06-01T12:43:36+00:00','error',0,0,0,'request failed: HTTPSConnectionPool(host=''www.governmentjobs.com'', port=443): Max retries exceeded with url: /SearchEngine/JobsFeed?agency= (Caused by ConnectTimeoutError(<HTTPSConnection(host=''www.governmentjobs.com'', port=443) at 0x7f068b76b510>, ''Connection to www.governmentjobs.com timed out. (connect timeout=30)''))',30063);
INSERT INTO source_log VALUES(82,'neogov','City of Rockville (MD)','2026-06-01T12:44:07+00:00','error',0,0,0,'request failed: HTTPSConnectionPool(host=''www.governmentjobs.com'', port=443): Max retries exceeded with url: /SearchEngine/JobsFeed?agency= (Caused by ConnectTimeoutError(<HTTPSConnection(host=''www.governmentjobs.com'', port=443) at 0x7f068b778b10>, ''Connection to www.governmentjobs.com timed out. (connect timeout=30)''))',30105);
INSERT INTO source_log VALUES(83,'neogov','Loudoun County (VA)','2026-06-01T12:44:39+00:00','error',0,0,0,'request failed: HTTPSConnectionPool(host=''www.governmentjobs.com'', port=443): Max retries exceeded with url: /SearchEngine/JobsFeed?agency= (Caused by ConnectTimeoutError(<HTTPSConnection(host=''www.governmentjobs.com'', port=443) at 0x7f068b7675d0>, ''Connection to www.governmentjobs.com timed out. (connect timeout=30)''))',30065);
INSERT INTO source_log VALUES(84,'neogov','Prince William County (VA)','2026-06-01T12:45:10+00:00','error',0,0,0,'request failed: HTTPSConnectionPool(host=''www.governmentjobs.com'', port=443): Max retries exceeded with url: /SearchEngine/JobsFeed?agency= (Caused by ConnectTimeoutError(<HTTPSConnection(host=''www.governmentjobs.com'', port=443) at 0x7f068b77a910>, ''Connection to www.governmentjobs.com timed out. (connect timeout=30)''))',30082);
INSERT INTO source_log VALUES(85,'greenhouse','World Resources Institute (WRI)','2026-06-03T11:59:53+00:00','error',0,0,0,'HTTP 404: {"status":404,"error":"Job board not found"}',160);
INSERT INTO source_log VALUES(86,'greenhouse','Bain & Company','2026-06-03T11:59:54+00:00','error',0,0,0,'HTTP 404: {"status":404,"error":"Job board not found"}',147);
INSERT INTO source_log VALUES(87,'greenhouse','Analysis Group','2026-06-03T11:59:55+00:00','error',0,0,0,'HTTP 404: {"status":404,"error":"Job board not found"}',134);
INSERT INTO source_log VALUES(88,'greenhouse','Atlantic Council','2026-06-03T11:59:56+00:00','error',0,0,0,'HTTP 404: {"status":404,"error":"Job board not found"}',99);
INSERT INTO source_log VALUES(89,'greenhouse','Center for American Progress (CAP)','2026-06-03T11:59:57+00:00','error',0,0,0,'HTTP 404: {"status":404,"error":"Job board not found"}',101);
INSERT INTO source_log VALUES(90,'greenhouse','Results for Development (R4D)','2026-06-03T11:59:59+00:00','error',0,0,0,'HTTP 404: {"status":404,"error":"Job board not found"}',155);
INSERT INTO source_log VALUES(91,'greenhouse','Rocky Mountain Institute (RMI)','2026-06-03T12:00:00+00:00','error',0,0,0,'HTTP 404: {"status":404,"error":"Job board not found"}',83);
INSERT INTO source_log VALUES(92,'greenhouse','Clean Air Task Force (CATF)','2026-06-03T12:00:01+00:00','error',0,0,0,'HTTP 404: {"status":404,"error":"Job board not found"}',69);
INSERT INTO source_log VALUES(93,'greenhouse','Center for Climate and Energy Solutions (C2ES)','2026-06-03T12:00:02+00:00','error',0,0,0,'HTTP 404: {"status":404,"error":"Job board not found"}',209);
INSERT INTO source_log VALUES(94,'greenhouse','Ceres','2026-06-03T12:00:03+00:00','error',0,0,0,'HTTP 404: {"status":404,"error":"Job board not found"}',132);
INSERT INTO source_log VALUES(95,'greenhouse','BlueGreen Alliance','2026-06-03T12:00:04+00:00','error',0,0,0,'HTTP 404: {"status":404,"error":"Job board not found"}',1374);
INSERT INTO source_log VALUES(96,'greenhouse','Bipartisan Policy Center','2026-06-03T12:00:07+00:00','error',0,0,0,'HTTP 404: {"status":404,"error":"Job board not found"}',69);
INSERT INTO source_log VALUES(97,'greenhouse','New America Foundation','2026-06-03T12:00:08+00:00','error',0,0,0,'HTTP 404: {"status":404,"error":"Job board not found"}',65);
INSERT INTO source_log VALUES(98,'greenhouse','Rockefeller Foundation','2026-06-03T12:00:09+00:00','error',0,0,0,'HTTP 404: {"status":404,"error":"Job board not found"}',93);
INSERT INTO source_log VALUES(99,'greenhouse','Bloomberg Philanthropies','2026-06-03T12:00:10+00:00','error',0,0,0,'HTTP 404: {"status":404,"error":"Job board not found"}',189);
INSERT INTO source_log VALUES(100,'greenhouse','Hewlett Foundation','2026-06-03T12:00:11+00:00','error',0,0,0,'HTTP 404: {"status":404,"error":"Job board not found"}',71);
INSERT INTO source_log VALUES(101,'greenhouse','IREX','2026-06-03T12:00:12+00:00','error',0,0,0,'HTTP 404: {"status":404,"error":"Job board not found"}',96);
INSERT INTO source_log VALUES(102,'greenhouse','Freedom House','2026-06-03T12:00:13+00:00','error',0,0,0,'HTTP 404: {"status":404,"error":"Job board not found"}',63);
INSERT INTO source_log VALUES(103,'greenjobs','GreenJobs.com (aggregated)','2026-06-03T12:00:14+00:00','success',20,3,17,NULL,24422);
INSERT INTO source_log VALUES(104,'neogov','Fairfax County Government','2026-06-03T12:00:38+00:00','error',0,0,0,'HTTP 400: Bad Request',407);
INSERT INTO source_log VALUES(105,'neogov','Arlington County Government','2026-06-03T12:00:40+00:00','error',0,0,0,'HTTP 400: Bad Request',483);
INSERT INTO source_log VALUES(106,'neogov','Montgomery County Government (MD)','2026-06-03T12:00:41+00:00','error',0,0,0,'HTTP 400: Bad Request',425);
INSERT INTO source_log VALUES(107,'neogov','Prince George''s County (MD)','2026-06-03T12:00:43+00:00','error',0,0,0,'HTTP 400: Bad Request',441);
INSERT INTO source_log VALUES(108,'neogov','City of Alexandria (VA)','2026-06-03T12:00:44+00:00','error',0,0,0,'HTTP 400: Bad Request',436);
INSERT INTO source_log VALUES(109,'neogov','Falls Church City (VA)','2026-06-03T12:00:46+00:00','error',0,0,0,'HTTP 400: Bad Request',404);
INSERT INTO source_log VALUES(110,'neogov','City of Rockville (MD)','2026-06-03T12:00:47+00:00','error',0,0,0,'request failed: HTTPSConnectionPool(host=''www.governmentjobs.com'', port=443): Max retries exceeded with url: /SearchEngine/JobsFeed?agency= (Caused by ConnectTimeoutError(<HTTPSConnection(host=''www.governmentjobs.com'', port=443) at 0x7f1869eff910>, ''Connection to www.governmentjobs.com timed out. (connect timeout=30)''))',30053);
INSERT INTO source_log VALUES(111,'neogov','Loudoun County (VA)','2026-06-03T12:01:18+00:00','error',0,0,0,'request failed: HTTPSConnectionPool(host=''www.governmentjobs.com'', port=443): Max retries exceeded with url: /SearchEngine/JobsFeed?agency= (Caused by ConnectTimeoutError(<HTTPSConnection(host=''www.governmentjobs.com'', port=443) at 0x7f1869f086d0>, ''Connection to www.governmentjobs.com timed out. (connect timeout=30)''))',30035);
INSERT INTO source_log VALUES(112,'neogov','Prince William County (VA)','2026-06-03T12:01:49+00:00','error',0,0,0,'request failed: HTTPSConnectionPool(host=''www.governmentjobs.com'', port=443): Max retries exceeded with url: /SearchEngine/JobsFeed?agency= (Caused by ConnectTimeoutError(<HTTPSConnection(host=''www.governmentjobs.com'', port=443) at 0x7f1869ef7310>, ''Connection to www.governmentjobs.com timed out. (connect timeout=30)''))',30074);
INSERT INTO source_log VALUES(113,'greenhouse','World Resources Institute (WRI)','2026-06-05T10:52:15+00:00','error',0,0,0,'HTTP 404: {"status":404,"error":"Job board not found"}',104);
INSERT INTO source_log VALUES(114,'greenhouse','Bain & Company','2026-06-05T10:52:16+00:00','error',0,0,0,'HTTP 404: {"status":404,"error":"Job board not found"}',69);
INSERT INTO source_log VALUES(115,'greenhouse','Analysis Group','2026-06-05T10:52:17+00:00','error',0,0,0,'HTTP 404: {"status":404,"error":"Job board not found"}',61);
INSERT INTO source_log VALUES(116,'greenhouse','Atlantic Council','2026-06-05T10:52:18+00:00','error',0,0,0,'HTTP 404: {"status":404,"error":"Job board not found"}',71);
INSERT INTO source_log VALUES(117,'greenhouse','Center for American Progress (CAP)','2026-06-05T10:52:19+00:00','error',0,0,0,'HTTP 404: {"status":404,"error":"Job board not found"}',72);
INSERT INTO source_log VALUES(118,'greenhouse','Results for Development (R4D)','2026-06-05T10:52:20+00:00','error',0,0,0,'HTTP 404: {"status":404,"error":"Job board not found"}',81);
INSERT INTO source_log VALUES(119,'greenhouse','Rocky Mountain Institute (RMI)','2026-06-05T10:52:22+00:00','error',0,0,0,'HTTP 404: {"status":404,"error":"Job board not found"}',65);
INSERT INTO source_log VALUES(120,'greenhouse','Clean Air Task Force (CATF)','2026-06-05T10:52:23+00:00','error',0,0,0,'HTTP 404: {"status":404,"error":"Job board not found"}',88);
INSERT INTO source_log VALUES(121,'greenhouse','Center for Climate and Energy Solutions (C2ES)','2026-06-05T10:52:24+00:00','error',0,0,0,'HTTP 404: {"status":404,"error":"Job board not found"}',57);
INSERT INTO source_log VALUES(122,'greenhouse','Ceres','2026-06-05T10:52:25+00:00','error',0,0,0,'HTTP 404: {"status":404,"error":"Job board not found"}',110);
INSERT INTO source_log VALUES(123,'greenhouse','BlueGreen Alliance','2026-06-05T10:52:26+00:00','error',0,0,0,'HTTP 404: {"status":404,"error":"Job board not found"}',56);
INSERT INTO source_log VALUES(124,'greenhouse','Bipartisan Policy Center','2026-06-05T10:52:27+00:00','error',0,0,0,'HTTP 404: {"status":404,"error":"Job board not found"}',93);
INSERT INTO source_log VALUES(125,'greenhouse','New America Foundation','2026-06-05T10:52:28+00:00','error',0,0,0,'HTTP 404: {"status":404,"error":"Job board not found"}',50);
INSERT INTO source_log VALUES(126,'greenhouse','Rockefeller Foundation','2026-06-05T10:52:29+00:00','error',0,0,0,'HTTP 404: {"status":404,"error":"Job board not found"}',52);
INSERT INTO source_log VALUES(127,'greenhouse','Bloomberg Philanthropies','2026-06-05T10:52:30+00:00','error',0,0,0,'HTTP 404: {"status":404,"error":"Job board not found"}',129);
INSERT INTO source_log VALUES(128,'greenhouse','Hewlett Foundation','2026-06-05T10:52:31+00:00','error',0,0,0,'HTTP 404: {"status":404,"error":"Job board not found"}',56);
INSERT INTO source_log VALUES(129,'greenhouse','IREX','2026-06-05T10:52:32+00:00','error',0,0,0,'HTTP 404: {"status":404,"error":"Job board not found"}',61);
INSERT INTO source_log VALUES(130,'greenhouse','Freedom House','2026-06-05T10:52:33+00:00','error',0,0,0,'HTTP 404: {"status":404,"error":"Job board not found"}',113);
INSERT INTO source_log VALUES(131,'greenjobs','GreenJobs.com (aggregated)','2026-06-05T10:52:34+00:00','success',20,4,16,NULL,16753);
INSERT INTO source_log VALUES(132,'neogov','Fairfax County Government','2026-06-05T10:52:51+00:00','error',0,0,0,'HTTP 400: Bad Request',436);
INSERT INTO source_log VALUES(133,'neogov','Arlington County Government','2026-06-05T10:52:52+00:00','error',0,0,0,'HTTP 400: Bad Request',369);
INSERT INTO source_log VALUES(134,'neogov','Montgomery County Government (MD)','2026-06-05T10:52:54+00:00','error',0,0,0,'HTTP 400: Bad Request',408);
INSERT INTO source_log VALUES(135,'neogov','Prince George''s County (MD)','2026-06-05T10:52:55+00:00','error',0,0,0,'HTTP 400: Bad Request',314);
INSERT INTO source_log VALUES(136,'neogov','City of Alexandria (VA)','2026-06-05T10:52:56+00:00','error',0,0,0,'HTTP 400: Bad Request',340);
INSERT INTO source_log VALUES(137,'neogov','Falls Church City (VA)','2026-06-05T10:52:58+00:00','error',0,0,0,'request failed: HTTPSConnectionPool(host=''www.governmentjobs.com'', port=443): Max retries exceeded with url: /SearchEngine/JobsFeed?agency= (Caused by ConnectTimeoutError(<HTTPSConnection(host=''www.governmentjobs.com'', port=443) at 0x7fdd99f4bdd0>, ''Connection to www.governmentjobs.com timed out. (connect timeout=30)''))',30119);
INSERT INTO source_log VALUES(138,'neogov','City of Rockville (MD)','2026-06-05T10:53:29+00:00','error',0,0,0,'request failed: HTTPSConnectionPool(host=''www.governmentjobs.com'', port=443): Max retries exceeded with url: /SearchEngine/JobsFeed?agency= (Caused by ConnectTimeoutError(<HTTPSConnection(host=''www.governmentjobs.com'', port=443) at 0x7fdd99f58c90>, ''Connection to www.governmentjobs.com timed out. (connect timeout=30)''))',30014);
INSERT INTO source_log VALUES(139,'neogov','Loudoun County (VA)','2026-06-05T10:54:00+00:00','error',0,0,0,'request failed: HTTPSConnectionPool(host=''www.governmentjobs.com'', port=443): Max retries exceeded with url: /SearchEngine/JobsFeed?agency= (Caused by ConnectTimeoutError(<HTTPSConnection(host=''www.governmentjobs.com'', port=443) at 0x7fdd99f58650>, ''Connection to www.governmentjobs.com timed out. (connect timeout=30)''))',30034);
INSERT INTO source_log VALUES(140,'neogov','Prince William County (VA)','2026-06-05T10:54:31+00:00','error',0,0,0,'request failed: HTTPSConnectionPool(host=''www.governmentjobs.com'', port=443): Max retries exceeded with url: /SearchEngine/JobsFeed?agency= (Caused by ConnectTimeoutError(<HTTPSConnection(host=''www.governmentjobs.com'', port=443) at 0x7fdd99f5aad0>, ''Connection to www.governmentjobs.com timed out. (connect timeout=30)''))',30113);
INSERT INTO source_log VALUES(141,'greenhouse','World Resources Institute (WRI)','2026-06-08T12:03:11+00:00','error',0,0,0,'HTTP 404: {"status":404,"error":"Job board not found"}',157);
INSERT INTO source_log VALUES(142,'greenhouse','Bain & Company','2026-06-08T12:03:12+00:00','error',0,0,0,'HTTP 404: {"status":404,"error":"Job board not found"}',98);
INSERT INTO source_log VALUES(143,'greenhouse','Analysis Group','2026-06-08T12:03:14+00:00','error',0,0,0,'HTTP 404: {"status":404,"error":"Job board not found"}',109);
INSERT INTO source_log VALUES(144,'greenhouse','Atlantic Council','2026-06-08T12:03:15+00:00','error',0,0,0,'HTTP 404: {"status":404,"error":"Job board not found"}',65);
INSERT INTO source_log VALUES(145,'greenhouse','Center for American Progress (CAP)','2026-06-08T12:03:16+00:00','error',0,0,0,'HTTP 404: {"status":404,"error":"Job board not found"}',84);
INSERT INTO source_log VALUES(146,'greenhouse','Results for Development (R4D)','2026-06-08T12:03:17+00:00','error',0,0,0,'HTTP 404: {"status":404,"error":"Job board not found"}',68);
INSERT INTO source_log VALUES(147,'greenhouse','Rocky Mountain Institute (RMI)','2026-06-08T12:03:18+00:00','error',0,0,0,'HTTP 404: {"status":404,"error":"Job board not found"}',63);
INSERT INTO source_log VALUES(148,'greenhouse','Clean Air Task Force (CATF)','2026-06-08T12:03:19+00:00','error',0,0,0,'HTTP 404: {"status":404,"error":"Job board not found"}',140);
INSERT INTO source_log VALUES(149,'greenhouse','Center for Climate and Energy Solutions (C2ES)','2026-06-08T12:03:20+00:00','error',0,0,0,'HTTP 404: {"status":404,"error":"Job board not found"}',136);
INSERT INTO source_log VALUES(150,'greenhouse','Ceres','2026-06-08T12:03:21+00:00','error',0,0,0,'HTTP 404: {"status":404,"error":"Job board not found"}',63);
INSERT INTO source_log VALUES(151,'greenhouse','BlueGreen Alliance','2026-06-08T12:03:22+00:00','error',0,0,0,'HTTP 404: {"status":404,"error":"Job board not found"}',70);
INSERT INTO source_log VALUES(152,'greenhouse','Bipartisan Policy Center','2026-06-08T12:03:23+00:00','error',0,0,0,'HTTP 404: {"status":404,"error":"Job board not found"}',164);
INSERT INTO source_log VALUES(153,'greenhouse','New America Foundation','2026-06-08T12:03:25+00:00','error',0,0,0,'HTTP 404: {"status":404,"error":"Job board not found"}',133);
INSERT INTO source_log VALUES(154,'greenhouse','Rockefeller Foundation','2026-06-08T12:03:26+00:00','error',0,0,0,'HTTP 404: {"status":404,"error":"Job board not found"}',96);
INSERT INTO source_log VALUES(155,'greenhouse','Bloomberg Philanthropies','2026-06-08T12:03:27+00:00','error',0,0,0,'HTTP 404: {"status":404,"error":"Job board not found"}',75);
INSERT INTO source_log VALUES(156,'greenhouse','Hewlett Foundation','2026-06-08T12:03:28+00:00','error',0,0,0,'HTTP 404: {"status":404,"error":"Job board not found"}',129);
INSERT INTO source_log VALUES(157,'greenhouse','IREX','2026-06-08T12:03:29+00:00','error',0,0,0,'HTTP 404: {"status":404,"error":"Job board not found"}',68);
INSERT INTO source_log VALUES(158,'greenhouse','Freedom House','2026-06-08T12:03:30+00:00','error',0,0,0,'HTTP 404: {"status":404,"error":"Job board not found"}',83);
INSERT INTO source_log VALUES(159,'greenjobs','GreenJobs.com (aggregated)','2026-06-08T12:03:31+00:00','success',20,4,16,NULL,15858);
INSERT INTO source_log VALUES(160,'neogov','Fairfax County Government','2026-06-08T12:03:47+00:00','error',0,0,0,'HTTP 400: Bad Request',403);
INSERT INTO source_log VALUES(161,'neogov','Arlington County Government','2026-06-08T12:03:48+00:00','error',0,0,0,'HTTP 400: Bad Request',402);
INSERT INTO source_log VALUES(162,'neogov','Montgomery County Government (MD)','2026-06-08T12:03:50+00:00','error',0,0,0,'HTTP 400: Bad Request',426);
INSERT INTO source_log VALUES(163,'neogov','Prince George''s County (MD)','2026-06-08T12:03:51+00:00','error',0,0,0,'HTTP 400: Bad Request',324);
INSERT INTO source_log VALUES(164,'neogov','City of Alexandria (VA)','2026-06-08T12:03:52+00:00','error',0,0,0,'request failed: HTTPSConnectionPool(host=''www.governmentjobs.com'', port=443): Max retries exceeded with url: /SearchEngine/JobsFeed?agency= (Caused by ConnectTimeoutError(<HTTPSConnection(host=''www.governmentjobs.com'', port=443) at 0x7fc408d1f390>, ''Connection to www.governmentjobs.com timed out. (connect timeout=30)''))',30125);
INSERT INTO source_log VALUES(165,'neogov','Falls Church City (VA)','2026-06-08T12:04:23+00:00','error',0,0,0,'request failed: HTTPSConnectionPool(host=''www.governmentjobs.com'', port=443): Max retries exceeded with url: /SearchEngine/JobsFeed?agency= (Caused by ConnectTimeoutError(<HTTPSConnection(host=''www.governmentjobs.com'', port=443) at 0x7fc408d28490>, ''Connection to www.governmentjobs.com timed out. (connect timeout=30)''))',30104);
INSERT INTO source_log VALUES(166,'neogov','City of Rockville (MD)','2026-06-08T12:04:55+00:00','error',0,0,0,'request failed: HTTPSConnectionPool(host=''www.governmentjobs.com'', port=443): Max retries exceeded with url: /SearchEngine/JobsFeed?agency= (Caused by ConnectTimeoutError(<HTTPSConnection(host=''www.governmentjobs.com'', port=443) at 0x7fc4093fdf90>, ''Connection to www.governmentjobs.com timed out. (connect timeout=30)''))',30008);
INSERT INTO source_log VALUES(167,'neogov','Loudoun County (VA)','2026-06-08T12:05:26+00:00','error',0,0,0,'request failed: HTTPSConnectionPool(host=''www.governmentjobs.com'', port=443): Max retries exceeded with url: /SearchEngine/JobsFeed?agency= (Caused by ConnectTimeoutError(<HTTPSConnection(host=''www.governmentjobs.com'', port=443) at 0x7fc408d2a390>, ''Connection to www.governmentjobs.com timed out. (connect timeout=30)''))',30021);
INSERT INTO source_log VALUES(168,'neogov','Prince William County (VA)','2026-06-08T12:05:57+00:00','error',0,0,0,'request failed: HTTPSConnectionPool(host=''www.governmentjobs.com'', port=443): Max retries exceeded with url: /SearchEngine/JobsFeed?agency= (Caused by ConnectTimeoutError(<HTTPSConnection(host=''www.governmentjobs.com'', port=443) at 0x7fc408d341d0>, ''Connection to www.governmentjobs.com timed out. (connect timeout=30)''))',30053);
INSERT INTO source_log VALUES(169,'greenhouse','World Resources Institute (WRI)','2026-06-17T11:54:16+00:00','error',0,0,0,'HTTP 404: {"status":404,"error":"Job board not found"}',77);
INSERT INTO source_log VALUES(170,'greenhouse','Bain & Company','2026-06-17T11:54:17+00:00','error',0,0,0,'HTTP 404: {"status":404,"error":"Job board not found"}',67);
INSERT INTO source_log VALUES(171,'greenhouse','Analysis Group','2026-06-17T11:54:18+00:00','error',0,0,0,'HTTP 404: {"status":404,"error":"Job board not found"}',76);
INSERT INTO source_log VALUES(172,'greenhouse','Atlantic Council','2026-06-17T11:54:19+00:00','error',0,0,0,'HTTP 404: {"status":404,"error":"Job board not found"}',64);
INSERT INTO source_log VALUES(173,'greenhouse','Center for American Progress (CAP)','2026-06-17T11:54:20+00:00','error',0,0,0,'HTTP 404: {"status":404,"error":"Job board not found"}',64);
INSERT INTO source_log VALUES(174,'greenhouse','Results for Development (R4D)','2026-06-17T11:54:21+00:00','error',0,0,0,'HTTP 404: {"status":404,"error":"Job board not found"}',76);
INSERT INTO source_log VALUES(175,'greenhouse','Rocky Mountain Institute (RMI)','2026-06-17T11:54:22+00:00','error',0,0,0,'HTTP 404: {"status":404,"error":"Job board not found"}',76);
INSERT INTO source_log VALUES(176,'greenhouse','Clean Air Task Force (CATF)','2026-06-17T11:54:23+00:00','error',0,0,0,'HTTP 404: {"status":404,"error":"Job board not found"}',70);
INSERT INTO source_log VALUES(177,'greenhouse','Center for Climate and Energy Solutions (C2ES)','2026-06-17T11:54:25+00:00','error',0,0,0,'HTTP 404: {"status":404,"error":"Job board not found"}',64);
INSERT INTO source_log VALUES(178,'greenhouse','Ceres','2026-06-17T11:54:26+00:00','error',0,0,0,'HTTP 404: {"status":404,"error":"Job board not found"}',73);
INSERT INTO source_log VALUES(179,'greenhouse','BlueGreen Alliance','2026-06-17T11:54:27+00:00','error',0,0,0,'HTTP 404: {"status":404,"error":"Job board not found"}',64);
INSERT INTO source_log VALUES(180,'greenhouse','Bipartisan Policy Center','2026-06-17T11:54:28+00:00','error',0,0,0,'HTTP 404: {"status":404,"error":"Job board not found"}',65);
INSERT INTO source_log VALUES(181,'greenhouse','New America Foundation','2026-06-17T11:54:29+00:00','error',0,0,0,'HTTP 404: {"status":404,"error":"Job board not found"}',64);
INSERT INTO source_log VALUES(182,'greenhouse','Rockefeller Foundation','2026-06-17T11:54:30+00:00','error',0,0,0,'HTTP 404: {"status":404,"error":"Job board not found"}',113);
INSERT INTO source_log VALUES(183,'greenhouse','Bloomberg Philanthropies','2026-06-17T11:54:31+00:00','error',0,0,0,'HTTP 404: {"status":404,"error":"Job board not found"}',80);
INSERT INTO source_log VALUES(184,'greenhouse','Hewlett Foundation','2026-06-17T11:54:32+00:00','error',0,0,0,'HTTP 404: {"status":404,"error":"Job board not found"}',68);
INSERT INTO source_log VALUES(185,'greenhouse','IREX','2026-06-17T11:54:33+00:00','error',0,0,0,'HTTP 404: {"status":404,"error":"Job board not found"}',63);
INSERT INTO source_log VALUES(186,'greenhouse','Freedom House','2026-06-17T11:54:34+00:00','error',0,0,0,'HTTP 404: {"status":404,"error":"Job board not found"}',64);
INSERT INTO source_log VALUES(187,'greenjobs','GreenJobs.com (aggregated)','2026-06-17T11:54:35+00:00','success',20,16,4,NULL,16564);
INSERT INTO source_log VALUES(188,'neogov','Fairfax County Government','2026-06-17T11:54:52+00:00','error',0,0,0,'HTTP 400: Bad Request',138);
INSERT INTO source_log VALUES(189,'neogov','Arlington County Government','2026-06-17T11:54:53+00:00','error',0,0,0,'HTTP 400: Bad Request',126);
INSERT INTO source_log VALUES(190,'neogov','Montgomery County Government (MD)','2026-06-17T11:54:54+00:00','error',0,0,0,'HTTP 400: Bad Request',118);
INSERT INTO source_log VALUES(191,'neogov','Prince George''s County (MD)','2026-06-17T11:54:55+00:00','error',0,0,0,'HTTP 400: Bad Request',123);
INSERT INTO source_log VALUES(192,'neogov','City of Alexandria (VA)','2026-06-17T11:54:56+00:00','error',0,0,0,'HTTP 400: Bad Request',131);
INSERT INTO source_log VALUES(193,'neogov','Falls Church City (VA)','2026-06-17T11:54:57+00:00','error',0,0,0,'HTTP 400: Bad Request',128);
INSERT INTO source_log VALUES(194,'neogov','City of Rockville (MD)','2026-06-17T11:54:58+00:00','error',0,0,0,'request failed: HTTPSConnectionPool(host=''www.governmentjobs.com'', port=443): Max retries exceeded with url: /SearchEngine/JobsFeed?agency= (Caused by ConnectTimeoutError(<HTTPSConnection(host=''www.governmentjobs.com'', port=443) at 0x7f52cee0f450>, ''Connection to www.governmentjobs.com timed out. (connect timeout=30)''))',30033);
INSERT INTO source_log VALUES(195,'neogov','Loudoun County (VA)','2026-06-17T11:55:29+00:00','error',0,0,0,'HTTP 400: Bad Request',114);
INSERT INTO source_log VALUES(196,'neogov','Prince William County (VA)','2026-06-17T11:55:30+00:00','error',0,0,0,'request failed: HTTPSConnectionPool(host=''www.governmentjobs.com'', port=443): Max retries exceeded with url: /SearchEngine/JobsFeed?agency= (Caused by ConnectTimeoutError(<HTTPSConnection(host=''www.governmentjobs.com'', port=443) at 0x7f52cee0f590>, ''Connection to www.governmentjobs.com timed out. (connect timeout=30)''))',30010);
INSERT INTO source_log VALUES(197,'greenhouse','World Resources Institute (WRI)','2026-06-19T11:27:10+00:00','error',0,0,0,'HTTP 404: {"status":404,"error":"Job board not found"}',261);
INSERT INTO source_log VALUES(198,'greenhouse','Bain & Company','2026-06-19T11:27:11+00:00','error',0,0,0,'HTTP 404: {"status":404,"error":"Job board not found"}',143);
INSERT INTO source_log VALUES(199,'greenhouse','Analysis Group','2026-06-19T11:27:12+00:00','error',0,0,0,'HTTP 404: {"status":404,"error":"Job board not found"}',126);
INSERT INTO source_log VALUES(200,'greenhouse','Atlantic Council','2026-06-19T11:27:13+00:00','error',0,0,0,'HTTP 404: {"status":404,"error":"Job board not found"}',209);
INSERT INTO source_log VALUES(201,'greenhouse','Center for American Progress (CAP)','2026-06-19T11:27:14+00:00','error',0,0,0,'HTTP 404: {"status":404,"error":"Job board not found"}',261);
INSERT INTO source_log VALUES(202,'greenhouse','Results for Development (R4D)','2026-06-19T11:27:16+00:00','error',0,0,0,'HTTP 404: {"status":404,"error":"Job board not found"}',125);
INSERT INTO source_log VALUES(203,'greenhouse','Rocky Mountain Institute (RMI)','2026-06-19T11:27:17+00:00','error',0,0,0,'HTTP 404: {"status":404,"error":"Job board not found"}',192);
INSERT INTO source_log VALUES(204,'greenhouse','Clean Air Task Force (CATF)','2026-06-19T11:27:18+00:00','error',0,0,0,'HTTP 404: {"status":404,"error":"Job board not found"}',147);
INSERT INTO source_log VALUES(205,'greenhouse','Center for Climate and Energy Solutions (C2ES)','2026-06-19T11:27:19+00:00','error',0,0,0,'HTTP 404: {"status":404,"error":"Job board not found"}',156);
INSERT INTO source_log VALUES(206,'greenhouse','Ceres','2026-06-19T11:27:20+00:00','error',0,0,0,'HTTP 404: {"status":404,"error":"Job board not found"}',168);
INSERT INTO source_log VALUES(207,'greenhouse','BlueGreen Alliance','2026-06-19T11:27:21+00:00','error',0,0,0,'HTTP 404: {"status":404,"error":"Job board not found"}',127);
INSERT INTO source_log VALUES(208,'greenhouse','Bipartisan Policy Center','2026-06-19T11:27:23+00:00','error',0,0,0,'HTTP 404: {"status":404,"error":"Job board not found"}',126);
INSERT INTO source_log VALUES(209,'greenhouse','New America Foundation','2026-06-19T11:27:24+00:00','error',0,0,0,'HTTP 404: {"status":404,"error":"Job board not found"}',126);
INSERT INTO source_log VALUES(210,'greenhouse','Rockefeller Foundation','2026-06-19T11:27:25+00:00','error',0,0,0,'HTTP 404: {"status":404,"error":"Job board not found"}',143);
INSERT INTO source_log VALUES(211,'greenhouse','Bloomberg Philanthropies','2026-06-19T11:27:26+00:00','error',0,0,0,'HTTP 404: {"status":404,"error":"Job board not found"}',127);
INSERT INTO source_log VALUES(212,'greenhouse','Hewlett Foundation','2026-06-19T11:27:27+00:00','error',0,0,0,'HTTP 404: {"status":404,"error":"Job board not found"}',171);
INSERT INTO source_log VALUES(213,'greenhouse','IREX','2026-06-19T11:27:28+00:00','error',0,0,0,'HTTP 404: {"status":404,"error":"Job board not found"}',209);
INSERT INTO source_log VALUES(214,'greenhouse','Freedom House','2026-06-19T11:27:29+00:00','error',0,0,0,'HTTP 404: {"status":404,"error":"Job board not found"}',166);
INSERT INTO source_log VALUES(215,'greenjobs','GreenJobs.com (aggregated)','2026-06-19T11:27:30+00:00','success',20,0,20,NULL,15011);
INSERT INTO source_log VALUES(216,'neogov','Fairfax County Government','2026-06-19T11:27:45+00:00','error',0,0,0,'HTTP 400: Bad Request',287);
INSERT INTO source_log VALUES(217,'neogov','Arlington County Government','2026-06-19T11:27:47+00:00','error',0,0,0,'HTTP 400: Bad Request',215);
INSERT INTO source_log VALUES(218,'neogov','Montgomery County Government (MD)','2026-06-19T11:27:48+00:00','error',0,0,0,'HTTP 400: Bad Request',279);
INSERT INTO source_log VALUES(219,'neogov','Prince George''s County (MD)','2026-06-19T11:27:49+00:00','error',0,0,0,'HTTP 400: Bad Request',215);
INSERT INTO source_log VALUES(220,'neogov','City of Alexandria (VA)','2026-06-19T11:27:50+00:00','error',0,0,0,'HTTP 400: Bad Request',283);
INSERT INTO source_log VALUES(221,'neogov','Falls Church City (VA)','2026-06-19T11:27:52+00:00','error',0,0,0,'request failed: HTTPSConnectionPool(host=''www.governmentjobs.com'', port=443): Max retries exceeded with url: /SearchEngine/JobsFeed?agency= (Caused by ConnectTimeoutError(<HTTPSConnection(host=''www.governmentjobs.com'', port=443) at 0x7f205cf82fd0>, ''Connection to www.governmentjobs.com timed out. (connect timeout=30)''))',30043);
INSERT INTO source_log VALUES(222,'neogov','City of Rockville (MD)','2026-06-19T11:28:23+00:00','error',0,0,0,'request failed: HTTPSConnectionPool(host=''www.governmentjobs.com'', port=443): Max retries exceeded with url: /SearchEngine/JobsFeed?agency= (Caused by ConnectTimeoutError(<HTTPSConnection(host=''www.governmentjobs.com'', port=443) at 0x7f205cf8c890>, ''Connection to www.governmentjobs.com timed out. (connect timeout=30)''))',30096);
INSERT INTO source_log VALUES(223,'neogov','Loudoun County (VA)','2026-06-19T11:28:54+00:00','error',0,0,0,'request failed: HTTPSConnectionPool(host=''www.governmentjobs.com'', port=443): Max retries exceeded with url: /SearchEngine/JobsFeed?agency= (Caused by ConnectTimeoutError(<HTTPSConnection(host=''www.governmentjobs.com'', port=443) at 0x7f205cf76f10>, ''Connection to www.governmentjobs.com timed out. (connect timeout=30)''))',30087);
INSERT INTO source_log VALUES(224,'neogov','Prince William County (VA)','2026-06-19T11:29:25+00:00','error',0,0,0,'request failed: HTTPSConnectionPool(host=''www.governmentjobs.com'', port=443): Max retries exceeded with url: /SearchEngine/JobsFeed?agency= (Caused by ConnectTimeoutError(<HTTPSConnection(host=''www.governmentjobs.com'', port=443) at 0x7f205cf8e690>, ''Connection to www.governmentjobs.com timed out. (connect timeout=30)''))',30200);
INSERT INTO source_log VALUES(225,'greenhouse','World Resources Institute (WRI)','2026-06-22T12:53:35+00:00','error',0,0,0,'HTTP 404: {"status":404,"error":"Job board not found"}',122);
INSERT INTO source_log VALUES(226,'greenhouse','Bain & Company','2026-06-22T12:53:36+00:00','error',0,0,0,'HTTP 404: {"status":404,"error":"Job board not found"}',96);
INSERT INTO source_log VALUES(227,'greenhouse','Analysis Group','2026-06-22T12:53:37+00:00','error',0,0,0,'HTTP 404: {"status":404,"error":"Job board not found"}',76);
INSERT INTO source_log VALUES(228,'greenhouse','Atlantic Council','2026-06-22T12:53:38+00:00','error',0,0,0,'HTTP 404: {"status":404,"error":"Job board not found"}',72);
INSERT INTO source_log VALUES(229,'greenhouse','Center for American Progress (CAP)','2026-06-22T12:53:40+00:00','error',0,0,0,'HTTP 404: {"status":404,"error":"Job board not found"}',79);
INSERT INTO source_log VALUES(230,'greenhouse','Results for Development (R4D)','2026-06-22T12:53:41+00:00','error',0,0,0,'HTTP 404: {"status":404,"error":"Job board not found"}',83);
INSERT INTO source_log VALUES(231,'greenhouse','Rocky Mountain Institute (RMI)','2026-06-22T12:53:42+00:00','error',0,0,0,'HTTP 404: {"status":404,"error":"Job board not found"}',70);
INSERT INTO source_log VALUES(232,'greenhouse','Clean Air Task Force (CATF)','2026-06-22T12:53:43+00:00','error',0,0,0,'HTTP 404: {"status":404,"error":"Job board not found"}',74);
INSERT INTO source_log VALUES(233,'greenhouse','Center for Climate and Energy Solutions (C2ES)','2026-06-22T12:53:44+00:00','error',0,0,0,'HTTP 404: {"status":404,"error":"Job board not found"}',77);
INSERT INTO source_log VALUES(234,'greenhouse','Ceres','2026-06-22T12:53:45+00:00','error',0,0,0,'HTTP 404: {"status":404,"error":"Job board not found"}',64);
INSERT INTO source_log VALUES(235,'greenhouse','BlueGreen Alliance','2026-06-22T12:53:46+00:00','error',0,0,0,'HTTP 404: {"status":404,"error":"Job board not found"}',81);
INSERT INTO source_log VALUES(236,'greenhouse','Bipartisan Policy Center','2026-06-22T12:53:47+00:00','error',0,0,0,'HTTP 404: {"status":404,"error":"Job board not found"}',78);
INSERT INTO source_log VALUES(237,'greenhouse','New America Foundation','2026-06-22T12:53:48+00:00','error',0,0,0,'HTTP 404: {"status":404,"error":"Job board not found"}',64);
INSERT INTO source_log VALUES(238,'greenhouse','Rockefeller Foundation','2026-06-22T12:53:49+00:00','error',0,0,0,'HTTP 404: {"status":404,"error":"Job board not found"}',70);
INSERT INTO source_log VALUES(239,'greenhouse','Bloomberg Philanthropies','2026-06-22T12:53:50+00:00','error',0,0,0,'HTTP 404: {"status":404,"error":"Job board not found"}',65);
INSERT INTO source_log VALUES(240,'greenhouse','Hewlett Foundation','2026-06-22T12:53:51+00:00','error',0,0,0,'HTTP 404: {"status":404,"error":"Job board not found"}',66);
INSERT INTO source_log VALUES(241,'greenhouse','IREX','2026-06-22T12:53:52+00:00','error',0,0,0,'HTTP 404: {"status":404,"error":"Job board not found"}',67);
INSERT INTO source_log VALUES(242,'greenhouse','Freedom House','2026-06-22T12:53:54+00:00','error',0,0,0,'HTTP 404: {"status":404,"error":"Job board not found"}',73);
INSERT INTO source_log VALUES(243,'greenjobs','GreenJobs.com (aggregated)','2026-06-22T12:53:54+00:00','success',20,0,20,NULL,17583);
INSERT INTO source_log VALUES(244,'neogov','Fairfax County Government','2026-06-22T12:54:12+00:00','error',0,0,0,'HTTP 400: Bad Request',148);
INSERT INTO source_log VALUES(245,'neogov','Arlington County Government','2026-06-22T12:54:13+00:00','error',0,0,0,'HTTP 400: Bad Request',94);
INSERT INTO source_log VALUES(246,'neogov','Montgomery County Government (MD)','2026-06-22T12:54:14+00:00','error',0,0,0,'HTTP 400: Bad Request',93);
INSERT INTO source_log VALUES(247,'neogov','Prince George''s County (MD)','2026-06-22T12:54:15+00:00','error',0,0,0,'HTTP 400: Bad Request',77);
INSERT INTO source_log VALUES(248,'neogov','City of Alexandria (VA)','2026-06-22T12:54:16+00:00','error',0,0,0,'HTTP 400: Bad Request',102);
INSERT INTO source_log VALUES(249,'neogov','Falls Church City (VA)','2026-06-22T12:54:17+00:00','error',0,0,0,'HTTP 400: Bad Request',81);
INSERT INTO source_log VALUES(250,'neogov','City of Rockville (MD)','2026-06-22T12:54:19+00:00','error',0,0,0,'request failed: HTTPSConnectionPool(host=''www.governmentjobs.com'', port=443): Max retries exceeded with url: /SearchEngine/JobsFeed?agency= (Caused by ConnectTimeoutError(<HTTPSConnection(host=''www.governmentjobs.com'', port=443) at 0x7f8f1e8a1910>, ''Connection to www.governmentjobs.com timed out. (connect timeout=30)''))',30035);
INSERT INTO source_log VALUES(251,'neogov','Loudoun County (VA)','2026-06-22T12:54:50+00:00','error',0,0,0,'request failed: HTTPSConnectionPool(host=''www.governmentjobs.com'', port=443): Max retries exceeded with url: /SearchEngine/JobsFeed?agency= (Caused by ConnectTimeoutError(<HTTPSConnection(host=''www.governmentjobs.com'', port=443) at 0x7f8f1e8ac350>, ''Connection to www.governmentjobs.com timed out. (connect timeout=30)''))',30023);
INSERT INTO source_log VALUES(252,'neogov','Prince William County (VA)','2026-06-22T12:55:21+00:00','error',0,0,0,'request failed: HTTPSConnectionPool(host=''www.governmentjobs.com'', port=443): Max retries exceeded with url: /SearchEngine/JobsFeed?agency= (Caused by ConnectTimeoutError(<HTTPSConnection(host=''www.governmentjobs.com'', port=443) at 0x7f8f1e8992d0>, ''Connection to www.governmentjobs.com timed out. (connect timeout=30)''))',30035);
INSERT INTO source_log VALUES(253,'greenhouse','World Resources Institute (WRI)','2026-06-24T10:25:24+00:00','error',0,0,0,'HTTP 404: {"status":404,"error":"Job board not found"}',283);
INSERT INTO source_log VALUES(254,'greenhouse','Bain & Company','2026-06-24T10:25:26+00:00','error',0,0,0,'HTTP 404: {"status":404,"error":"Job board not found"}',97);
INSERT INTO source_log VALUES(255,'greenhouse','Analysis Group','2026-06-24T10:25:27+00:00','error',0,0,0,'HTTP 404: {"status":404,"error":"Job board not found"}',71);
INSERT INTO source_log VALUES(256,'greenhouse','Atlantic Council','2026-06-24T10:25:28+00:00','error',0,0,0,'HTTP 404: {"status":404,"error":"Job board not found"}',71);
INSERT INTO source_log VALUES(257,'greenhouse','Center for American Progress (CAP)','2026-06-24T10:25:29+00:00','error',0,0,0,'HTTP 404: {"status":404,"error":"Job board not found"}',92);
INSERT INTO source_log VALUES(258,'greenhouse','Results for Development (R4D)','2026-06-24T10:25:30+00:00','error',0,0,0,'HTTP 404: {"status":404,"error":"Job board not found"}',95);
INSERT INTO source_log VALUES(259,'greenhouse','Rocky Mountain Institute (RMI)','2026-06-24T10:25:31+00:00','error',0,0,0,'HTTP 404: {"status":404,"error":"Job board not found"}',116);
INSERT INTO source_log VALUES(260,'greenhouse','Clean Air Task Force (CATF)','2026-06-24T10:25:32+00:00','error',0,0,0,'HTTP 404: {"status":404,"error":"Job board not found"}',93);
INSERT INTO source_log VALUES(261,'greenhouse','Center for Climate and Energy Solutions (C2ES)','2026-06-24T10:25:33+00:00','error',0,0,0,'HTTP 404: {"status":404,"error":"Job board not found"}',72);
INSERT INTO source_log VALUES(262,'greenhouse','Ceres','2026-06-24T10:25:34+00:00','error',0,0,0,'HTTP 404: {"status":404,"error":"Job board not found"}',98);
INSERT INTO source_log VALUES(263,'greenhouse','BlueGreen Alliance','2026-06-24T10:25:35+00:00','error',0,0,0,'HTTP 404: {"status":404,"error":"Job board not found"}',70);
INSERT INTO source_log VALUES(264,'greenhouse','Bipartisan Policy Center','2026-06-24T10:25:37+00:00','error',0,0,0,'HTTP 404: {"status":404,"error":"Job board not found"}',75);
INSERT INTO source_log VALUES(265,'greenhouse','New America Foundation','2026-06-24T10:25:38+00:00','error',0,0,0,'HTTP 404: {"status":404,"error":"Job board not found"}',70);
INSERT INTO source_log VALUES(266,'greenhouse','Rockefeller Foundation','2026-06-24T10:25:39+00:00','error',0,0,0,'HTTP 404: {"status":404,"error":"Job board not found"}',100);
INSERT INTO source_log VALUES(267,'greenhouse','Bloomberg Philanthropies','2026-06-24T10:25:40+00:00','error',0,0,0,'HTTP 404: {"status":404,"error":"Job board not found"}',69);
INSERT INTO source_log VALUES(268,'greenhouse','Hewlett Foundation','2026-06-24T10:25:41+00:00','error',0,0,0,'HTTP 404: {"status":404,"error":"Job board not found"}',70);
INSERT INTO source_log VALUES(269,'greenhouse','IREX','2026-06-24T10:25:42+00:00','error',0,0,0,'HTTP 404: {"status":404,"error":"Job board not found"}',70);
INSERT INTO source_log VALUES(270,'greenhouse','Freedom House','2026-06-24T10:25:43+00:00','error',0,0,0,'HTTP 404: {"status":404,"error":"Job board not found"}',72);
INSERT INTO source_log VALUES(271,'greenjobs','GreenJobs.com (aggregated)','2026-06-24T10:25:43+00:00','success',20,1,19,NULL,25100);
INSERT INTO source_log VALUES(272,'neogov','Fairfax County Government','2026-06-24T10:26:09+00:00','error',0,0,0,'HTTP 400: Bad Request',299);
INSERT INTO source_log VALUES(273,'neogov','Arlington County Government','2026-06-24T10:26:10+00:00','error',0,0,0,'HTTP 400: Bad Request',264);
INSERT INTO source_log VALUES(274,'neogov','Montgomery County Government (MD)','2026-06-24T10:26:11+00:00','error',0,0,0,'HTTP 400: Bad Request',295);
INSERT INTO source_log VALUES(275,'neogov','Prince George''s County (MD)','2026-06-24T10:26:13+00:00','error',0,0,0,'HTTP 400: Bad Request',357);
INSERT INTO source_log VALUES(276,'neogov','City of Alexandria (VA)','2026-06-24T10:26:14+00:00','error',0,0,0,'HTTP 400: Bad Request',266);
INSERT INTO source_log VALUES(277,'neogov','Falls Church City (VA)','2026-06-24T10:26:15+00:00','error',0,0,0,'request failed: HTTPSConnectionPool(host=''www.governmentjobs.com'', port=443): Max retries exceeded with url: /SearchEngine/JobsFeed?agency= (Caused by ConnectTimeoutError(<HTTPSConnection(host=''www.governmentjobs.com'', port=443) at 0x7f55eac1b2d0>, ''Connection to www.governmentjobs.com timed out. (connect timeout=30)''))',30133);
INSERT INTO source_log VALUES(278,'neogov','City of Rockville (MD)','2026-06-24T10:26:47+00:00','error',0,0,0,'request failed: HTTPSConnectionPool(host=''www.governmentjobs.com'', port=443): Max retries exceeded with url: /SearchEngine/JobsFeed?agency= (Caused by ConnectTimeoutError(<HTTPSConnection(host=''www.governmentjobs.com'', port=443) at 0x7f55eac24190>, ''Connection to www.governmentjobs.com timed out. (connect timeout=30)''))',30034);
INSERT INTO source_log VALUES(279,'neogov','Loudoun County (VA)','2026-06-24T10:27:18+00:00','error',0,0,0,'request failed: HTTPSConnectionPool(host=''www.governmentjobs.com'', port=443): Max retries exceeded with url: /SearchEngine/JobsFeed?agency= (Caused by ConnectTimeoutError(<HTTPSConnection(host=''www.governmentjobs.com'', port=443) at 0x7f55eac01d50>, ''Connection to www.governmentjobs.com timed out. (connect timeout=30)''))',30142);
INSERT INTO source_log VALUES(280,'neogov','Prince William County (VA)','2026-06-24T10:27:49+00:00','error',0,0,0,'request failed: HTTPSConnectionPool(host=''www.governmentjobs.com'', port=443): Max retries exceeded with url: /SearchEngine/JobsFeed?agency= (Caused by ConnectTimeoutError(<HTTPSConnection(host=''www.governmentjobs.com'', port=443) at 0x7f55eac25fd0>, ''Connection to www.governmentjobs.com timed out. (connect timeout=30)''))',30034);
CREATE TABLE url_telemetry (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    url             TEXT NOT NULL,
    domain          TEXT NOT NULL,          -- normalized hostname, e.g. 'boards.greenhouse.io'
    ats_guess       TEXT NOT NULL,          -- canonical ATS id; 'unknown' for unrecognized
    ats_slug        TEXT,                   -- tenant/company slug when extractable
    company_name    TEXT,                   -- as known to the posting (may be NULL)
    source          TEXT NOT NULL,          -- 'greenhouse', 'jobspy:indeed', 'manual', ...
    added_at        TEXT NOT NULL,          -- ISO-8601 UTC, first time we saw this URL from this source
    posting_id      INTEGER,                -- FK to postings.id; NULL if telemetry written before posting committed

    FOREIGN KEY (posting_id) REFERENCES postings(id),
    UNIQUE (url, source)
);
INSERT INTO url_telemetry VALUES(1,'https://greenjobs.greenjobsearch.org/jobs/sustainability-enforcement-attorney/','greenjobs.greenjobsearch.org','unknown',NULL,'NYC Department of Buildings','greenjobs','2026-05-27T10:59:03+00:00',NULL);
INSERT INTO url_telemetry VALUES(2,'https://greenjobs.greenjobsearch.org/jobs/advocacy-director-2/','greenjobs.greenjobsearch.org','unknown',NULL,'Permit Power','greenjobs','2026-05-27T10:59:03+00:00',NULL);
INSERT INTO url_telemetry VALUES(3,'https://greenjobs.greenjobsearch.org/jobs/landscape-technician-gardener-2/','greenjobs.greenjobsearch.org','unknown',NULL,'Mad Hatter Garden Designs','greenjobs','2026-05-27T10:59:03+00:00',NULL);
INSERT INTO url_telemetry VALUES(4,'https://greenjobs.greenjobsearch.org/jobs/research-manager/','greenjobs.greenjobsearch.org','unknown',NULL,'Energy and Policy Institute','greenjobs','2026-05-27T10:59:03+00:00',NULL);
INSERT INTO url_telemetry VALUES(5,'https://greenjobs.greenjobsearch.org/jobs/research-fellow-3/','greenjobs.greenjobsearch.org','unknown',NULL,'Energy and Policy Institute','greenjobs','2026-05-27T10:59:03+00:00',NULL);
INSERT INTO url_telemetry VALUES(6,'https://greenjobs.greenjobsearch.org/jobs/texas-regional-organizer/','greenjobs.greenjobsearch.org','unknown',NULL,'Beyond Petrochemicals','greenjobs','2026-05-27T10:59:03+00:00',NULL);
INSERT INTO url_telemetry VALUES(7,'https://greenjobs.greenjobsearch.org/jobs/gardener-4/','greenjobs.greenjobsearch.org','unknown',NULL,'Smiling Gardens','greenjobs','2026-05-27T10:59:03+00:00',NULL);
INSERT INTO url_telemetry VALUES(8,'https://greenjobs.greenjobsearch.org/jobs/regional-wildlife-program-manager-region-1-wms-band-2/','greenjobs.greenjobsearch.org','unknown',NULL,'Region 1 - WMS Band 2 - Washington Department of Fish & Wildlife','greenjobs','2026-05-27T10:59:03+00:00',NULL);
INSERT INTO url_telemetry VALUES(9,'https://greenjobs.greenjobsearch.org/jobs/americorps-project-conserve-member/','greenjobs.greenjobsearch.org','unknown',NULL,'Conserving Carolina','greenjobs','2026-05-27T10:59:03+00:00',NULL);
INSERT INTO url_telemetry VALUES(10,'https://greenjobs.greenjobsearch.org/jobs/minnesota-greencorps-americorps-member-4/','greenjobs.greenjobsearch.org','unknown',NULL,'State of Minnesota','greenjobs','2026-05-27T10:59:03+00:00',NULL);
INSERT INTO url_telemetry VALUES(11,'https://greenjobs.greenjobsearch.org/jobs/environmental-services-manager/','greenjobs.greenjobsearch.org','unknown',NULL,'The Woodlands Township','greenjobs','2026-05-27T10:59:03+00:00',NULL);
INSERT INTO url_telemetry VALUES(12,'https://greenjobs.greenjobsearch.org/jobs/deputy-director-alternative-energy/','greenjobs.greenjobsearch.org','unknown',NULL,'NYC Department of Buildings','greenjobs','2026-05-27T10:59:03+00:00',NULL);
INSERT INTO url_telemetry VALUES(13,'https://greenjobs.greenjobsearch.org/jobs/solid-waste-manager/','greenjobs.greenjobsearch.org','unknown',NULL,'Thurston County Public Works','greenjobs','2026-05-27T10:59:03+00:00',NULL);
INSERT INTO url_telemetry VALUES(14,'https://greenjobs.greenjobsearch.org/jobs/executive-director-200/','greenjobs.greenjobsearch.org','unknown',NULL,'Equity Trust, Inc.','greenjobs','2026-05-27T10:59:03+00:00',NULL);
INSERT INTO url_telemetry VALUES(15,'https://greenjobs.greenjobsearch.org/jobs/south-coastkeeper/','greenjobs.greenjobsearch.org','unknown',NULL,'Save The Bay','greenjobs','2026-05-27T10:59:03+00:00',NULL);
INSERT INTO url_telemetry VALUES(16,'https://greenjobs.greenjobsearch.org/jobs/president-11/','greenjobs.greenjobsearch.org','unknown',NULL,'The Land Conservancy of New Jersey','greenjobs','2026-05-27T10:59:03+00:00',NULL);
INSERT INTO url_telemetry VALUES(17,'https://greenjobs.greenjobsearch.org/jobs/pacific-education-institute-executive-director/','greenjobs.greenjobsearch.org','unknown',NULL,'Pacific Education Institute','greenjobs','2026-05-27T10:59:03+00:00',NULL);
INSERT INTO url_telemetry VALUES(18,'https://greenjobs.greenjobsearch.org/jobs/new-england-policy-manager/','greenjobs.greenjobsearch.org','unknown',NULL,'American Farmland Trust','greenjobs','2026-05-27T10:59:03+00:00',NULL);
INSERT INTO url_telemetry VALUES(19,'https://greenjobs.greenjobsearch.org/jobs/midwest-program-manager/','greenjobs.greenjobsearch.org','unknown',NULL,'Land Trust Alliance','greenjobs','2026-05-27T10:59:03+00:00',NULL);
INSERT INTO url_telemetry VALUES(20,'https://greenjobs.greenjobsearch.org/jobs/emergency-response-team-americorps-member/','greenjobs.greenjobsearch.org','unknown',NULL,'AmeriCorps St. Louis','greenjobs','2026-05-27T10:59:03+00:00',NULL);
INSERT INTO url_telemetry VALUES(21,'https://greenjobs.greenjobsearch.org/jobs/media-communications-summer-intern/','greenjobs.greenjobsearch.org','unknown',NULL,'Smart Surfaces Coalition','greenjobs','2026-05-29T10:51:48+00:00',NULL);
INSERT INTO url_telemetry VALUES(22,'https://greenjobs.greenjobsearch.org/jobs/regional-farmland-preservation-program-coordinator/','greenjobs.greenjobsearch.org','unknown',NULL,'NJ Farmland Preservation Program/State Agriculture Development Committee (SADC)','greenjobs','2026-05-29T10:51:48+00:00',NULL);
INSERT INTO url_telemetry VALUES(41,'https://greenjobs.greenjobsearch.org/jobs/industry-content-senior-associate/','greenjobs.greenjobsearch.org','unknown',NULL,'Greenlight America','greenjobs','2026-06-01T12:43:12+00:00',NULL);
INSERT INTO url_telemetry VALUES(42,'https://greenjobs.greenjobsearch.org/jobs/congressional-innovation-fellow/','greenjobs.greenjobsearch.org','unknown',NULL,'TechCongress','greenjobs','2026-06-01T12:43:12+00:00',NULL);
INSERT INTO url_telemetry VALUES(61,'https://greenjobs.greenjobsearch.org/jobs/senior-government-affairs-manager/','greenjobs.greenjobsearch.org','unknown',NULL,'Western Resource Advocates (WRA)','greenjobs','2026-06-03T12:00:16+00:00',NULL);
INSERT INTO url_telemetry VALUES(62,'https://greenjobs.greenjobsearch.org/jobs/associate-director-of-government-affairs/','greenjobs.greenjobsearch.org','unknown',NULL,'Western Resource Advocates (WRA)','greenjobs','2026-06-03T12:00:16+00:00',NULL);
INSERT INTO url_telemetry VALUES(63,'https://greenjobs.greenjobsearch.org/jobs/chief-executive-officer-23/','greenjobs.greenjobsearch.org','unknown',NULL,'dream.org','greenjobs','2026-06-03T12:00:16+00:00',NULL);
INSERT INTO url_telemetry VALUES(81,'https://greenjobs.greenjobsearch.org/jobs/funder-relations-manager/','greenjobs.greenjobsearch.org','unknown',NULL,'Climate Justice Alliance','greenjobs','2026-06-05T10:52:34+00:00',NULL);
INSERT INTO url_telemetry VALUES(82,'https://greenjobs.greenjobsearch.org/jobs/development-data-and-research-coordinator/','greenjobs.greenjobsearch.org','unknown',NULL,'Climate Justice Alliance','greenjobs','2026-06-05T10:52:34+00:00',NULL);
INSERT INTO url_telemetry VALUES(83,'https://greenjobs.greenjobsearch.org/jobs/people-operations-lead/','greenjobs.greenjobsearch.org','unknown',NULL,'Climate Justice Alliance','greenjobs','2026-06-05T10:52:34+00:00',NULL);
INSERT INTO url_telemetry VALUES(84,'https://greenjobs.greenjobsearch.org/jobs/research-specialist-water-climate-equity/','greenjobs.greenjobsearch.org','unknown',NULL,'Pacific Institute','greenjobs','2026-06-05T10:52:34+00:00',NULL);
INSERT INTO url_telemetry VALUES(101,'https://greenjobs.greenjobsearch.org/jobs/executive-director-204/','greenjobs.greenjobsearch.org','unknown',NULL,'Illinois Nutrient Research & Education Council','greenjobs','2026-06-08T12:03:31+00:00',101);
INSERT INTO url_telemetry VALUES(102,'https://greenjobs.greenjobsearch.org/jobs/vice-president-2/','greenjobs.greenjobsearch.org','unknown',NULL,'Spitfire Strategies','greenjobs','2026-06-08T12:03:31+00:00',102);
INSERT INTO url_telemetry VALUES(103,'https://greenjobs.greenjobsearch.org/jobs/california-conservation-manager-norcal/','greenjobs.greenjobsearch.org','unknown',NULL,'The Wilderness Society','greenjobs','2026-06-08T12:03:31+00:00',103);
INSERT INTO url_telemetry VALUES(104,'https://greenjobs.greenjobsearch.org/jobs/alaska-state-director-3/','greenjobs.greenjobsearch.org','unknown',NULL,'The Wilderness Society','greenjobs','2026-06-08T12:03:31+00:00',104);
INSERT INTO url_telemetry VALUES(121,'https://greenjobs.greenjobsearch.org/jobs/customer-success-manager/','greenjobs.greenjobsearch.org','unknown',NULL,'Pathways','greenjobs','2026-06-17T11:54:35+00:00',121);
INSERT INTO url_telemetry VALUES(122,'https://greenjobs.greenjobsearch.org/jobs/executive-director-206/','greenjobs.greenjobsearch.org','unknown',NULL,'Bellevue Botanical Garden Society','greenjobs','2026-06-17T11:54:35+00:00',122);
INSERT INTO url_telemetry VALUES(123,'https://greenjobs.greenjobsearch.org/jobs/program-and-education-manager/','greenjobs.greenjobsearch.org','unknown',NULL,'Philadelphia Ship Preservation Guild','greenjobs','2026-06-17T11:54:35+00:00',123);
INSERT INTO url_telemetry VALUES(124,'https://greenjobs.greenjobsearch.org/jobs/new-york-senior-program-manager/','greenjobs.greenjobsearch.org','unknown',NULL,'Land Trust Alliance','greenjobs','2026-06-17T11:54:35+00:00',124);
INSERT INTO url_telemetry VALUES(125,'https://greenjobs.greenjobsearch.org/jobs/sare-grant-program-admin-farmer-grant/','greenjobs.greenjobsearch.org','unknown',NULL,'Farmer Grant - University of Vermont','greenjobs','2026-06-17T11:54:35+00:00',125);
INSERT INTO url_telemetry VALUES(126,'https://greenjobs.greenjobsearch.org/jobs/executive-director-205/','greenjobs.greenjobsearch.org','unknown',NULL,'Columbia Land Trust','greenjobs','2026-06-17T11:54:35+00:00',126);
INSERT INTO url_telemetry VALUES(127,'https://greenjobs.greenjobsearch.org/jobs/manager-ii-community-choice-energy-aggregation-program-grade-m2/','greenjobs.greenjobsearch.org','unknown',NULL,'Montgomery County, MD Government','greenjobs','2026-06-17T11:54:35+00:00',127);
INSERT INTO url_telemetry VALUES(128,'https://greenjobs.greenjobsearch.org/jobs/research-associate-7/','greenjobs.greenjobsearch.org','unknown',NULL,'Boundless Impact Research & Analytics','greenjobs','2026-06-17T11:54:35+00:00',128);
INSERT INTO url_telemetry VALUES(129,'https://greenjobs.greenjobsearch.org/jobs/land-conservation-manager-2/','greenjobs.greenjobsearch.org','unknown',NULL,'New Mexico Land Conservancy','greenjobs','2026-06-17T11:54:35+00:00',129);
INSERT INTO url_telemetry VALUES(130,'https://greenjobs.greenjobsearch.org/jobs/air-quality-modeler-2/','greenjobs.greenjobsearch.org','unknown',NULL,'Clark County Department of Environment and Sustainability','greenjobs','2026-06-17T11:54:35+00:00',130);
INSERT INTO url_telemetry VALUES(131,'https://greenjobs.greenjobsearch.org/jobs/environmental-outreach-specialist/','greenjobs.greenjobsearch.org','unknown',NULL,'Hampton Roads Planning District Commission','greenjobs','2026-06-17T11:54:35+00:00',131);
INSERT INTO url_telemetry VALUES(132,'https://greenjobs.greenjobsearch.org/jobs/david-b-goldstein-fellow/','greenjobs.greenjobsearch.org','unknown',NULL,'Institute for Market Transformation','greenjobs','2026-06-17T11:54:35+00:00',132);
INSERT INTO url_telemetry VALUES(133,'https://greenjobs.greenjobsearch.org/jobs/arboretum-and-botanical-gardens-manager/','greenjobs.greenjobsearch.org','unknown',NULL,'Los Angeles Community College District','greenjobs','2026-06-17T11:54:35+00:00',133);
INSERT INTO url_telemetry VALUES(134,'https://greenjobs.greenjobsearch.org/jobs/uk-healthcare-manager-part-time-contractor/','greenjobs.greenjobsearch.org','unknown',NULL,'Part-time Contractor - Greener By Default','greenjobs','2026-06-17T11:54:35+00:00',134);
INSERT INTO url_telemetry VALUES(135,'https://greenjobs.greenjobsearch.org/jobs/us-healthcare-manager/','greenjobs.greenjobsearch.org','unknown',NULL,'Greener By Default','greenjobs','2026-06-17T11:54:35+00:00',135);
INSERT INTO url_telemetry VALUES(136,'https://greenjobs.greenjobsearch.org/jobs/arms-national-coordinating-attorney/','greenjobs.greenjobsearch.org','unknown',NULL,'Land Trust Alliance','greenjobs','2026-06-17T11:54:35+00:00',136);
INSERT INTO url_telemetry VALUES(181,'https://greenjobs.greenjobsearch.org/jobs/executive-director-and-chief-executive-officer/','greenjobs.greenjobsearch.org','unknown',NULL,'New Jersey League of Conservation Voters','greenjobs','2026-06-24T10:25:44+00:00',181);
CREATE TABLE achievements (
    id          TEXT PRIMARY KEY,
    name        TEXT NOT NULL,
    description TEXT NOT NULL,
    icon        TEXT NOT NULL,
    earned_at   TEXT,
    seen_at     TEXT
);
INSERT INTO achievements VALUES('first_app','First brave step','Sent your first application','🌱',NULL,NULL);
INSERT INTO achievements VALUES('tailor_5','Tailor''s apprentice','Tailored 5 resumes','🧵',NULL,NULL);
INSERT INTO achievements VALUES('week_streak','Week one warrior','7-day streak','🔥',NULL,NULL);
INSERT INTO achievements VALUES('interview','First interview','Status → Interviewing','💬',NULL,NULL);
INSERT INTO achievements VALUES('apps_10','Double digits','10 applications submitted','🏅',NULL,NULL);
INSERT INTO achievements VALUES('weekly_15','Quota crusher','Hit 15 in a week','🚀',NULL,NULL);
INSERT INTO achievements VALUES('month_streak','Steady gardener','30-day streak','🌳',NULL,NULL);
INSERT INTO achievements VALUES('offer','The big one','Receive an offer','🌟',NULL,NULL);
DELETE FROM sqlite_sequence;
INSERT INTO sqlite_sequence VALUES('source_log',280);
INSERT INTO sqlite_sequence VALUES('postings',200);
INSERT INTO sqlite_sequence VALUES('url_telemetry',200);
CREATE INDEX idx_postings_company        ON postings(company);
CREATE INDEX idx_postings_first_seen     ON postings(first_seen);
CREATE INDEX idx_postings_is_active      ON postings(is_active);
CREATE INDEX idx_postings_fit_score      ON postings(fit_score);
CREATE INDEX idx_postings_interest_level ON postings(interest_level);
CREATE INDEX idx_applications_posting_id ON applications(posting_id);
CREATE INDEX idx_applications_status     ON applications(status);
CREATE INDEX idx_source_log_run_at ON source_log(run_at);
CREATE INDEX idx_source_log_source ON source_log(source);
CREATE INDEX idx_url_telemetry_domain    ON url_telemetry(domain);
CREATE INDEX idx_url_telemetry_ats_guess ON url_telemetry(ats_guess);
CREATE INDEX idx_url_telemetry_ats_slug  ON url_telemetry(ats_slug);
CREATE INDEX idx_url_telemetry_source    ON url_telemetry(source);
CREATE INDEX idx_url_telemetry_added_at  ON url_telemetry(added_at);
COMMIT;
