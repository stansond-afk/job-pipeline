PRAGMA foreign_keys=OFF;
BEGIN TRANSACTION;
CREATE TABLE postings (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,

    -- Origin
    source          TEXT NOT NULL,          -- 'greenhouse', 'lever', 'usajobs', 'neogov', ...
    source_job_id   TEXT NOT NULL,          -- the ATS's own ID for this posting
    company         TEXT NOT NULL,          -- canonical company name (matches targets.csv)

    -- Posting content
    role            TEXT NOT NULL,          -- role title
    location        TEXT,                   -- as posted — e.g. "Washington, DC" or "Remote - US"
    department      TEXT,                   -- ATS-provided dept/team if any
    url             TEXT NOT NULL,          -- link to the posting
    jd_text         TEXT,                   -- full job description (may be long)

    -- Metadata
    posted_at       TEXT,                   -- ISO-8601 UTC, if the ATS provides it
    first_seen      TEXT NOT NULL,          -- ISO-8601 UTC, when WE first saw this posting
    last_seen       TEXT NOT NULL,          -- ISO-8601 UTC, most recent scrape that still saw it
    is_active       INTEGER NOT NULL DEFAULT 1,  -- 0 = no longer appearing in source feed

    -- Scoring (populated by scoring module later)
    fit_score       REAL,                   -- 0.0 - 1.0, NULL until scored
    score_notes     TEXT,                   -- why it scored that way

    -- Interest level (D27 — per-posting triage signal, separate from fit_score)
    interest_level  TEXT NOT NULL DEFAULT 'not_reviewed',
        -- valid values: 'not_reviewed' (default), 'not_interested',
        --               'interested', 'very_interested'
    interest_updated_at TEXT,           -- ISO-8601 UTC, set on every interest change.
                                        -- Feeds daily-streak computation (D33). NULL = never changed.

    UNIQUE (source, source_job_id)
);
INSERT INTO postings VALUES(1,'greenjobs','https://greenjobs.greenjobsearch.org/?post_type=job_listing&p=31197','NYC Department of Buildings','Sustainability Enforcement Attorney','New York, New York, United States',NULL,'https://greenjobs.greenjobsearch.org/jobs/sustainability-enforcement-attorney/','Join the fight against climate change and take advantage of a unique opportunity on the cutting edge of climate policy at the New York City Department of Buildings (DOB). DOB has an essential role in implementing and enforcing New York City’s ground-breaking climate policies, including Local Law 97, which significantly reduces greenhouse gas emissions from […] The post Sustainability Enforcement Attorney appeared first on Green Jobs Board - greenjobsearch.org .','Tue, 26 May 2026 17:21:27 +0000','2026-05-27T10:59:03+00:00','2026-05-29T10:51:48+00:00',1,0.0,'FILTERED: blacklist: attorney','not_reviewed',NULL);
INSERT INTO postings VALUES(2,'greenjobs','https://greenjobs.greenjobsearch.org/?post_type=job_listing&p=31194','Permit Power','Advocacy Director','Anywhere',NULL,'https://greenjobs.greenjobsearch.org/jobs/advocacy-director-2/','Join Permit Power to oversee state advocacy campaigns to slash utility bills for American families by dramatically accelerating the installation of home solar and batteries. What we do at Permit Power Permit Power is on a mission to make it cheap and easy for American families to power their lives by cutting the red tape […] The post Advocacy Director appeared first on Green Jobs Board - greenjobsearch.org .','Tue, 26 May 2026 17:01:11 +0000','2026-05-27T10:59:03+00:00','2026-05-29T10:51:48+00:00',1,0.0,'no_keyword_hits','not_reviewed',NULL);
INSERT INTO postings VALUES(3,'greenjobs','https://greenjobs.greenjobsearch.org/?post_type=job_listing&p=30038','Mad Hatter Garden Designs','Landscape Technician/Gardener','Portland, Oregon, United States',NULL,'https://greenjobs.greenjobsearch.org/jobs/landscape-technician-gardener-2/','WE ARE DEDICATED TO ORGANIC GARDENING! Mad Hatter Garden Designs is looking for passionate, experienced, full-time gardeners. Do the work you love and make a difference! We specialize in organic gardening, garden design, installation, and maintenance with a focus on plants for high-end residential clients. This is NOT a mow and blow crew. We are […] The post Landscape Technician/Gardener appeared first on Green Jobs Board - greenjobsearch.org .','Mon, 25 May 2026 10:32:27 +0000','2026-05-27T10:59:03+00:00','2026-05-29T10:51:48+00:00',1,0.0,'no_keyword_hits','not_reviewed',NULL);
INSERT INTO postings VALUES(4,'greenjobs','https://greenjobs.greenjobsearch.org/?post_type=job_listing&p=31165','Energy and Policy Institute','Research Manager','Anywhere',NULL,'https://greenjobs.greenjobsearch.org/jobs/research-manager/','Research Manager Location: Flexible within the U.S., with a preference for candidates in California Experience: Deep experience in energy advocacy, research, journalism or politics Summary: The Energy and Policy Institute is seeking a new team member who can help us hold the utility monopolies that are blocking clean energy and lower bills for ratepayers accountable for […] The post Research Manager appeared first on Green Jobs Board - greenjobsearch.org .','Tue, 19 May 2026 17:02:16 +0000','2026-05-27T10:59:03+00:00','2026-05-29T10:51:48+00:00',1,0.0,'no_keyword_hits','not_reviewed',NULL);
INSERT INTO postings VALUES(5,'greenjobs','https://greenjobs.greenjobsearch.org/?post_type=job_listing&p=31161','Energy and Policy Institute','Research Fellow','Anywhere',NULL,'https://greenjobs.greenjobsearch.org/jobs/research-fellow-3/','Summary: The Energy and Policy Institute is seeking research fellows to help hold utility monopolies accountable for actions that block clean energy and drive up costs for ratepayers. Research fellows will support our investigations across the entire team. About EPI: EPI is a watchdog organization that exposes the harms posed by fossil-fuel and monopoly utility interests to […] The post Research Fellow appeared first on Green Jobs Board - greenjobsearch.org .','Tue, 19 May 2026 16:54:51 +0000','2026-05-27T10:59:03+00:00','2026-05-29T10:51:48+00:00',1,0.0,'no_keyword_hits','not_reviewed',NULL);
INSERT INTO postings VALUES(6,'greenjobs','https://greenjobs.greenjobsearch.org/?post_type=job_listing&p=31151','Beyond Petrochemicals','Texas Regional Organizer','Texas, United States',NULL,'https://greenjobs.greenjobsearch.org/jobs/texas-regional-organizer/','Texas Regional Organizer Beyond Petrochemicals: People Over Pollution About the Opportunity Beyond Petrochemicals is seeking a Texas Regional Organizer to advance grassroots efforts to address the expansion of the petrochemical industry and build long-term community power. This role supports and strengthens on-the-ground organizing in Texas by working closely with grassroots partners, community leaders, and coalition […] The post Texas Regional Organizer appeared first on Green Jobs Board - greenjobsearch.org .','Fri, 15 May 2026 15:23:36 +0000','2026-05-27T10:59:03+00:00','2026-05-29T10:51:48+00:00',1,0.0,'no_keyword_hits','not_reviewed',NULL);
INSERT INTO postings VALUES(7,'greenjobs','https://greenjobs.greenjobsearch.org/?post_type=job_listing&p=29882','Smiling Gardens','Fine Gardener','Portland, Oregon, United States',NULL,'https://greenjobs.greenjobsearch.org/jobs/gardener-4/','We are looking for a skilled Fine Gardener for a small, women-owned gardening company in Portland. We provide plant care, revitalization, installation, pruning, weeding, ongoing maintenance and more. We work with plants and soil with an ecological mindset. Our focus is detail hands on work with the plants, no mowing lawns. We are a small […] The post Fine Gardener appeared first on Green Jobs Board - greenjobsearch.org .','Sat, 24 Jan 2026 22:03:30 +0000','2026-05-27T10:59:03+00:00','2026-05-29T10:51:48+00:00',1,0.0,'no_keyword_hits','not_reviewed',NULL);
INSERT INTO postings VALUES(8,'greenjobs','https://greenjobs.greenjobsearch.org/?post_type=job_listing&p=31104','Region 1 - WMS Band 2 - Washington Department of Fish & Wildlife','Regional Wildlife Program Manager – Region 1 – WMS Band 2','Spokane, Washington, United States',NULL,'https://greenjobs.greenjobsearch.org/jobs/regional-wildlife-program-manager-region-1-wms-band-2/','Title – Regional Wildlife Program Manager – Region 1 Classification – WMS Band 2 Job Status – Full-Time/Permanent Salary – $121,000.00 – $126,000.00 Annually WDFW Program – Wildlife Program Duty Station – Spokane, Washington – Spokane County Eastern Region 1 -Counties Served – Asotin, Columbia, Ferry, Garfield, Lincoln, Pend Oreille, Spokane, Stevens, Walla Walla, and Whitman. Remote Employment – This position may include […] The post Regional Wildlife Program Manager – Region 1 – WMS Band 2 appeared first on Green Jobs Board - greenjobsearch.org .','Thu, 14 May 2026 20:41:14 +0000','2026-05-27T10:59:03+00:00','2026-05-29T10:51:48+00:00',1,0.0,'no_keyword_hits','not_reviewed',NULL);
INSERT INTO postings VALUES(9,'greenjobs','https://greenjobs.greenjobsearch.org/?post_type=job_listing&p=31136','Conserving Carolina','AmeriCorps Project Conserve Member','Hendersonville, North Carolina, United States',NULL,'https://greenjobs.greenjobsearch.org/jobs/americorps-project-conserve-member/','AmeriCorps Project Conserve seeks dedicated individuals to fill full-time positions serving critical conservation needs in western North Carolina. Each full-time member will serve a minimum of 1700 hours from September 9, 2026 – August 6, 2027. Members serve with host site organizations working to protect the unique natural resources of the southern Blue Ridge Mountain […] The post AmeriCorps Project Conserve Member appeared first on Green Jobs Board - greenjobsearch.org .','Thu, 14 May 2026 18:53:33 +0000','2026-05-27T10:59:03+00:00','2026-05-29T10:51:48+00:00',1,0.0,'no_keyword_hits','not_reviewed',NULL);
INSERT INTO postings VALUES(10,'greenjobs','https://greenjobs.greenjobsearch.org/?post_type=job_listing&p=31114','State of Minnesota','Minnesota GreenCorps AmeriCorps Member','Minnesota, United States',NULL,'https://greenjobs.greenjobsearch.org/jobs/minnesota-greencorps-americorps-member-4/','Minnesota GreenCorps is a statewide AmeriCorps program coordinated by the Minnesota Pollution Control Agency (MPCA), with a mission to preserve and protect Minnesota’s environment and strengthen communities. MN GreenCorps members serve full-time at local governments, tribal nations, nonprofit organizations, or educational institutions throughout the state. Members address critical environmental issues and help communities build resiliency while gaining […] The post Minnesota GreenCorps AmeriCorps Member appeared first on Green Jobs Board - greenjobsearch.org .','Thu, 14 May 2026 18:29:22 +0000','2026-05-27T10:59:03+00:00','2026-05-29T10:51:48+00:00',1,0.0,'no_keyword_hits','not_reviewed',NULL);
INSERT INTO postings VALUES(11,'greenjobs','https://greenjobs.greenjobsearch.org/?post_type=job_listing&p=31132','The Woodlands Township','Environmental Services Manager','The Woodlands, Texas, United States',NULL,'https://greenjobs.greenjobsearch.org/jobs/environmental-services-manager/','Summary of Duties: Manage solid waste and recycling collection services and the development and delivery of related community education programs and materials. Research, develop and oversee public education programs and events that encourage source reduction, conservation, and recycling. Heighten community awareness of relevant environmental issues through programs and services while promoting and utilizing community volunteers […] The post Environmental Services Manager appeared first on Green Jobs Board - greenjobsearch.org .','Thu, 14 May 2026 18:27:11 +0000','2026-05-27T10:59:03+00:00','2026-05-29T10:51:48+00:00',1,0.0,'no_keyword_hits','not_reviewed',NULL);
INSERT INTO postings VALUES(12,'greenjobs','https://greenjobs.greenjobsearch.org/?post_type=job_listing&p=31127','NYC Department of Buildings','Deputy Director, Alternative Energy','New York, New York, United States',NULL,'https://greenjobs.greenjobsearch.org/jobs/deputy-director-alternative-energy/','Salary Range: $75,443.00 – $141,446.00 Per NYC Administrative Code, Section 28-103.31, the NYC Department of Buildings is required to establish an Office of Alternative Energy. The duties of the office include, but are not limited to: Establishing a program to assist with the technical review and approval of applications and other documents submitted to the […] The post Deputy Director, Alternative Energy appeared first on Green Jobs Board - greenjobsearch.org .','Thu, 14 May 2026 17:44:13 +0000','2026-05-27T10:59:03+00:00','2026-05-29T10:51:48+00:00',1,0.0,'no_keyword_hits','not_reviewed',NULL);
INSERT INTO postings VALUES(13,'greenjobs','https://greenjobs.greenjobsearch.org/?post_type=job_listing&p=31119','Thurston County Public Works','Solid Waste Manager','Lacey, Washington, United States',NULL,'https://greenjobs.greenjobsearch.org/jobs/solid-waste-manager/','The salary for this position is: $8,630.00 – $11,352.00 monthly. Thurston County Public Works is recruiting for a Solid Waste Manager to lead our dynamic, energetic, and innovative team. This position is a direct report to the Public Works Director and plays a key role serving on the Department’s Leadership Team. We are seeking a proven professional with […] The post Solid Waste Manager appeared first on Green Jobs Board - greenjobsearch.org .','Thu, 14 May 2026 17:25:45 +0000','2026-05-27T10:59:03+00:00','2026-05-29T10:51:48+00:00',1,0.0,'no_keyword_hits','not_reviewed',NULL);
INSERT INTO postings VALUES(14,'greenjobs','https://greenjobs.greenjobsearch.org/?post_type=job_listing&p=30869','Equity Trust, Inc.','Executive Director','Amherst, Massachusetts, United States',NULL,'https://greenjobs.greenjobsearch.org/jobs/executive-director-200/','Equity Trust (Amherst MA), a small, national nonprofit advancing socially equitable land ownership and economics rooted in social justice and environmental sustainability, is seeking an Executive Director. This role blends strategic and hands-on leadership across operations, staff supervision, fundraising, communication and organizational planning, with a focus on strengthening the organization’s capacity to respond to the […] The post Executive Director appeared first on Green Jobs Board - greenjobsearch.org .','Thu, 14 May 2026 00:01:03 +0000','2026-05-27T10:59:03+00:00','2026-05-29T10:51:48+00:00',1,0.0,'no_keyword_hits','not_reviewed',NULL);
INSERT INTO postings VALUES(15,'greenjobs','https://greenjobs.greenjobsearch.org/?post_type=job_listing&p=31088','Save The Bay','South Coastkeeper','Providence, Rhode Island, United States',NULL,'https://greenjobs.greenjobsearch.org/jobs/south-coastkeeper/','South County Coastkeeper Reports To: Director of Advocacy Position Description The South County Coastkeeper is a member of Save The Bay’s Advocacy Team and leads the organization’s Coastkeeper program. As Save The Bay’s on-the-water advocate and watchdog along Rhode Island’s south coast, the Coastkeeper serves as a knowledgeable and credible voice on water quality, pollution, […] The post South Coastkeeper appeared first on Green Jobs Board - greenjobsearch.org .','Wed, 13 May 2026 11:58:34 +0000','2026-05-27T10:59:03+00:00','2026-05-29T10:51:48+00:00',1,0.0,'no_keyword_hits','not_reviewed',NULL);
INSERT INTO postings VALUES(16,'greenjobs','https://greenjobs.greenjobsearch.org/?post_type=job_listing&p=31094','The Land Conservancy of New Jersey','President','Boonton, New Jersey, United States',NULL,'https://greenjobs.greenjobsearch.org/jobs/president-11/','President Reporting to the Board of Trustees Boonton, NJ The Land Conservancy of New Jersey (TLCNJ) is a member-supported nonprofit founded in 1981 that permanently protects New Jersey’s lands, waters, forests, and farms. Through conservation, stewardship, and education, TLCNJ helps safeguard clean water, productive agriculture, sustainable forests, and public access to open space for the […] The post President appeared first on Green Jobs Board - greenjobsearch.org .','Tue, 12 May 2026 17:59:34 +0000','2026-05-27T10:59:03+00:00','2026-05-29T10:51:48+00:00',1,0.0,'no_keyword_hits','not_reviewed',NULL);
INSERT INTO postings VALUES(17,'greenjobs','https://greenjobs.greenjobsearch.org/?post_type=job_listing&p=31065','Pacific Education Institute','Executive Director','Olympia, Washington, United States',NULL,'https://greenjobs.greenjobsearch.org/jobs/pacific-education-institute-executive-director/','PACIFIC EDUCATION INSTITUTE EXECUTIVE DIRECTOR Hybrid based in Olympia, WA Reports To: Board of Directors Annual Budget: ~$1M Total Staff: 8 Salary: $120,000 – $140,000 annually, DOE The Organization The Pacific Education Institute (PEI) was founded in 2003 by a consortium of leaders from the Washington Forest Protection Association (WFPA), Washington Department of Fish and […] The post Executive Director appeared first on Green Jobs Board - greenjobsearch.org .','Fri, 08 May 2026 19:14:56 +0000','2026-05-27T10:59:03+00:00','2026-05-29T10:51:48+00:00',1,0.0,'no_keyword_hits','not_reviewed',NULL);
INSERT INTO postings VALUES(18,'greenjobs','https://greenjobs.greenjobsearch.org/?post_type=job_listing&p=31060','American Farmland Trust','New England Policy Manager (Remote)','Northampton, Massachusetts, United States',NULL,'https://greenjobs.greenjobsearch.org/jobs/new-england-policy-manager/','Level: Management Position Type: Full Time Location: Fully Remote • AFT Northampton Office – Northampton, MA 01060 Remote Type: Fully Remote Salary Range: $75,000.00 – $80,000.00 Salary Description Who We Are American Farmland Trust is the only national organization that takes a holistic approach to agriculture, focusing on the land itself, the agricultural practices used […] The post New England Policy Manager (Remote) appeared first on Green Jobs Board - greenjobsearch.org .','Fri, 08 May 2026 16:53:45 +0000','2026-05-27T10:59:03+00:00','2026-05-27T10:59:03+00:00',1,0.0,'no_keyword_hits','not_reviewed',NULL);
INSERT INTO postings VALUES(19,'greenjobs','https://greenjobs.greenjobsearch.org/?post_type=job_listing&p=31056','Land Trust Alliance','Midwest Program Manager','Anywhere',NULL,'https://greenjobs.greenjobsearch.org/jobs/midwest-program-manager/','Location: Remote, but candidates must reside in the Midwest region (IL, IN, IA, MI, MN, MO, OH, WI) Overview The Land Trust Alliance is the voice of the land trust community. As the national leader in policy, standards and education, we work passionately to support land trusts across America so they can save more land […] The post Midwest Program Manager appeared first on Green Jobs Board - greenjobsearch.org .','Fri, 08 May 2026 16:07:09 +0000','2026-05-27T10:59:03+00:00','2026-05-29T10:51:48+00:00',1,0.0,'no_keyword_hits','not_reviewed',NULL);
INSERT INTO postings VALUES(20,'greenjobs','https://greenjobs.greenjobsearch.org/?post_type=job_listing&p=31052','AmeriCorps St. Louis','Emergency Response Team (AmeriCorps Member)','St. Louis, Missouri, United States',NULL,'https://greenjobs.greenjobsearch.org/jobs/emergency-response-team-americorps-member/','Program Details: Full Time AmeriCorps State/National Service Term September 2026 – July 2027 Based in St. Louis, MO Service projects in Missouri and Illinois, summer culmination project out of state, disaster deployment opportunities $20,400 living stipend total (paid out bi-weekly) & $7,395 Education Award Application window: April 1 – June 15 Details of the position […] The post Emergency Response Team (AmeriCorps Member) appeared first on Green Jobs Board - greenjobsearch.org .','Thu, 07 May 2026 20:23:08 +0000','2026-05-27T10:59:03+00:00','2026-05-27T10:59:03+00:00',1,0.0,'no_keyword_hits','not_reviewed',NULL);
INSERT INTO postings VALUES(21,'greenjobs','https://greenjobs.greenjobsearch.org/?post_type=job_listing&p=31216','Smart Surfaces Coalition','Media/Communications Summer Intern','Washington, District of Columbia, United States',NULL,'https://greenjobs.greenjobsearch.org/jobs/media-communications-summer-intern/','Make an impact: Apply to be the Media/Communications Summer Intern with the Smart Surfaces Coalition! The Smart Surfaces Coalition (SSC) supports the rapid adoption of Smart Surfaces—a term referring to the integrated deployment of reflective, porous, and green surfaces, solar PV, and urban trees city-wide—in cities in the US and globally. SSC has built this […] The post Media/Communications Summer Intern appeared first on Green Jobs Board - greenjobsearch.org .','Wed, 27 May 2026 21:29:25 +0000','2026-05-29T10:51:48+00:00','2026-05-29T10:51:48+00:00',1,0.0,'no_keyword_hits','not_reviewed',NULL);
INSERT INTO postings VALUES(22,'greenjobs','https://greenjobs.greenjobsearch.org/?post_type=job_listing&p=31212','NJ Farmland Preservation Program/State Agriculture Development Committee (SADC)','Regional Farmland Preservation Program Coordinator','Trenton, New Jersey, United States',NULL,'https://greenjobs.greenjobsearch.org/jobs/regional-farmland-preservation-program-coordinator/','STARTING SALARY: $51,479.83 6 MONTH INCREASE: $53,807.27 Candidate moves into the next Civil Service title after 12 months with annual increase as per the union contract 35-hour work week, excellent benefits, 13 paid holidays, hybrid work environment CLOSING DATE: 6/29/2026 Under the close supervision of a supervisory official within the State Agricultural Development Committee (SADC), […] The post Regional Farmland Preservation Program Coordinator appeared first on Green Jobs Board - greenjobsearch.org .','Wed, 27 May 2026 15:30:52 +0000','2026-05-29T10:51:48+00:00','2026-05-29T10:51:48+00:00',1,0.109399999999999997,'tools(1) | geo:other_us*0.5','not_reviewed',NULL);
CREATE TABLE applications (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    posting_id      INTEGER NOT NULL,

    -- Pipeline status
    status          TEXT NOT NULL DEFAULT 'new',
        -- valid values: 'new', 'reviewing', 'tailored', 'submitted',
        --               'interviewing', 'offered', 'rejected', 'withdrawn', 'closed'

    -- Tracking
    submitted_at    TEXT,                   -- ISO-8601 UTC, when she actually applied
    resume_path     TEXT,                   -- path to tailored resume .docx, if any
    cover_letter_path TEXT,                 -- path to cover letter .docx, if any
    notes           TEXT,                   -- freeform notes from her

    -- JD capture (D18 — snapshot at Apply time, edited via modal)
    jd_snapshot     TEXT,                   -- full JD text as the user edited/confirmed it
    tailored_notes  TEXT,                   -- paste-back from the Claude tailoring chat

    -- Housekeeping
    created_at      TEXT NOT NULL,
    updated_at      TEXT NOT NULL,

    FOREIGN KEY (posting_id) REFERENCES postings(id)
);
CREATE TABLE source_log (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    source          TEXT NOT NULL,          -- 'greenhouse', 'lever', etc.
    company         TEXT,                   -- NULL when the run hits many companies
    run_at          TEXT NOT NULL,          -- ISO-8601 UTC, when scraper started
    status          TEXT NOT NULL,          -- 'success', 'error', 'skipped'
    postings_found  INTEGER NOT NULL DEFAULT 0,
    postings_new    INTEGER NOT NULL DEFAULT 0,
    postings_updated INTEGER NOT NULL DEFAULT 0,
    error_message   TEXT,
    duration_ms     INTEGER
);
INSERT INTO source_log VALUES(1,'greenhouse','World Resources Institute (WRI)','2026-05-27T10:58:43+00:00','error',0,0,0,'HTTP 404: {"status":404,"error":"Job board not found"}',162);
INSERT INTO source_log VALUES(2,'greenhouse','Bain & Company','2026-05-27T10:58:44+00:00','error',0,0,0,'HTTP 404: {"status":404,"error":"Job board not found"}',73);
INSERT INTO source_log VALUES(3,'greenhouse','Analysis Group','2026-05-27T10:58:45+00:00','error',0,0,0,'HTTP 404: {"status":404,"error":"Job board not found"}',119);
INSERT INTO source_log VALUES(4,'greenhouse','Atlantic Council','2026-05-27T10:58:46+00:00','error',0,0,0,'HTTP 404: {"status":404,"error":"Job board not found"}',102);
INSERT INTO source_log VALUES(5,'greenhouse','Center for American Progress (CAP)','2026-05-27T10:58:47+00:00','error',0,0,0,'HTTP 404: {"status":404,"error":"Job board not found"}',71);
INSERT INTO source_log VALUES(6,'greenhouse','Results for Development (R4D)','2026-05-27T10:58:49+00:00','error',0,0,0,'HTTP 404: {"status":404,"error":"Job board not found"}',79);
INSERT INTO source_log VALUES(7,'greenhouse','Rocky Mountain Institute (RMI)','2026-05-27T10:58:50+00:00','error',0,0,0,'HTTP 404: {"status":404,"error":"Job board not found"}',76);
INSERT INTO source_log VALUES(8,'greenhouse','Clean Air Task Force (CATF)','2026-05-27T10:58:51+00:00','error',0,0,0,'HTTP 404: {"status":404,"error":"Job board not found"}',115);
INSERT INTO source_log VALUES(9,'greenhouse','Center for Climate and Energy Solutions (C2ES)','2026-05-27T10:58:52+00:00','error',0,0,0,'HTTP 404: {"status":404,"error":"Job board not found"}',134);
INSERT INTO source_log VALUES(10,'greenhouse','Ceres','2026-05-27T10:58:53+00:00','error',0,0,0,'HTTP 404: {"status":404,"error":"Job board not found"}',62);
INSERT INTO source_log VALUES(11,'greenhouse','BlueGreen Alliance','2026-05-27T10:58:54+00:00','error',0,0,0,'HTTP 404: {"status":404,"error":"Job board not found"}',271);
INSERT INTO source_log VALUES(12,'greenhouse','Bipartisan Policy Center','2026-05-27T10:58:55+00:00','error',0,0,0,'HTTP 404: {"status":404,"error":"Job board not found"}',72);
INSERT INTO source_log VALUES(13,'greenhouse','New America Foundation','2026-05-27T10:58:56+00:00','error',0,0,0,'HTTP 404: {"status":404,"error":"Job board not found"}',85);
INSERT INTO source_log VALUES(14,'greenhouse','Rockefeller Foundation','2026-05-27T10:58:57+00:00','error',0,0,0,'HTTP 404: {"status":404,"error":"Job board not found"}',66);
INSERT INTO source_log VALUES(15,'greenhouse','Bloomberg Philanthropies','2026-05-27T10:58:59+00:00','error',0,0,0,'HTTP 404: {"status":404,"error":"Job board not found"}',72);
INSERT INTO source_log VALUES(16,'greenhouse','Hewlett Foundation','2026-05-27T10:59:00+00:00','error',0,0,0,'HTTP 404: {"status":404,"error":"Job board not found"}',81);
INSERT INTO source_log VALUES(17,'greenhouse','IREX','2026-05-27T10:59:01+00:00','error',0,0,0,'HTTP 404: {"status":404,"error":"Job board not found"}',71);
INSERT INTO source_log VALUES(18,'greenhouse','Freedom House','2026-05-27T10:59:02+00:00','error',0,0,0,'HTTP 404: {"status":404,"error":"Job board not found"}',270);
INSERT INTO source_log VALUES(19,'greenjobs','GreenJobs.com (aggregated)','2026-05-27T10:59:02+00:00','success',20,20,0,NULL,17475);
INSERT INTO source_log VALUES(20,'neogov','Fairfax County Government','2026-05-27T10:59:20+00:00','error',0,0,0,'HTTP 400: Bad Request',407);
INSERT INTO source_log VALUES(21,'neogov','Arlington County Government','2026-05-27T10:59:22+00:00','error',0,0,0,'HTTP 400: Bad Request',309);
INSERT INTO source_log VALUES(22,'neogov','Montgomery County Government (MD)','2026-05-27T10:59:23+00:00','error',0,0,0,'HTTP 400: Bad Request',284);
INSERT INTO source_log VALUES(23,'neogov','Prince George''s County (MD)','2026-05-27T10:59:24+00:00','error',0,0,0,'HTTP 400: Bad Request',381);
INSERT INTO source_log VALUES(24,'neogov','City of Alexandria (VA)','2026-05-27T10:59:26+00:00','error',0,0,0,'HTTP 400: Bad Request',318);
INSERT INTO source_log VALUES(25,'neogov','Falls Church City (VA)','2026-05-27T10:59:27+00:00','error',0,0,0,'request failed: HTTPSConnectionPool(host=''www.governmentjobs.com'', port=443): Max retries exceeded with url: /SearchEngine/JobsFeed?agency= (Caused by ConnectTimeoutError(<HTTPSConnection(host=''www.governmentjobs.com'', port=443) at 0x7f96946ab010>, ''Connection to www.governmentjobs.com timed out. (connect timeout=30)''))',30034);
INSERT INTO source_log VALUES(26,'neogov','City of Rockville (MD)','2026-05-27T10:59:58+00:00','error',0,0,0,'request failed: HTTPSConnectionPool(host=''www.governmentjobs.com'', port=443): Max retries exceeded with url: /SearchEngine/JobsFeed?agency= (Caused by ConnectTimeoutError(<HTTPSConnection(host=''www.governmentjobs.com'', port=443) at 0x7f96946b4a90>, ''Connection to www.governmentjobs.com timed out. (connect timeout=30)''))',30037);
INSERT INTO source_log VALUES(27,'neogov','Loudoun County (VA)','2026-05-27T11:00:29+00:00','error',0,0,0,'request failed: HTTPSConnectionPool(host=''www.governmentjobs.com'', port=443): Max retries exceeded with url: /SearchEngine/JobsFeed?agency= (Caused by ConnectTimeoutError(<HTTPSConnection(host=''www.governmentjobs.com'', port=443) at 0x7f96946a3150>, ''Connection to www.governmentjobs.com timed out. (connect timeout=30)''))',30034);
INSERT INTO source_log VALUES(28,'neogov','Prince William County (VA)','2026-05-27T11:01:00+00:00','error',0,0,0,'request failed: HTTPSConnectionPool(host=''www.governmentjobs.com'', port=443): Max retries exceeded with url: /SearchEngine/JobsFeed?agency= (Caused by ConnectTimeoutError(<HTTPSConnection(host=''www.governmentjobs.com'', port=443) at 0x7f96946b6890>, ''Connection to www.governmentjobs.com timed out. (connect timeout=30)''))',30018);
INSERT INTO source_log VALUES(29,'greenhouse','World Resources Institute (WRI)','2026-05-29T10:51:28+00:00','error',0,0,0,'HTTP 404: {"status":404,"error":"Job board not found"}',164);
INSERT INTO source_log VALUES(30,'greenhouse','Bain & Company','2026-05-29T10:51:29+00:00','error',0,0,0,'HTTP 404: {"status":404,"error":"Job board not found"}',526);
INSERT INTO source_log VALUES(31,'greenhouse','Analysis Group','2026-05-29T10:51:31+00:00','error',0,0,0,'HTTP 404: {"status":404,"error":"Job board not found"}',114);
INSERT INTO source_log VALUES(32,'greenhouse','Atlantic Council','2026-05-29T10:51:32+00:00','error',0,0,0,'HTTP 404: {"status":404,"error":"Job board not found"}',132);
INSERT INTO source_log VALUES(33,'greenhouse','Center for American Progress (CAP)','2026-05-29T10:51:33+00:00','error',0,0,0,'HTTP 404: {"status":404,"error":"Job board not found"}',80);
INSERT INTO source_log VALUES(34,'greenhouse','Results for Development (R4D)','2026-05-29T10:51:34+00:00','error',0,0,0,'HTTP 404: {"status":404,"error":"Job board not found"}',108);
INSERT INTO source_log VALUES(35,'greenhouse','Rocky Mountain Institute (RMI)','2026-05-29T10:51:35+00:00','error',0,0,0,'HTTP 404: {"status":404,"error":"Job board not found"}',92);
INSERT INTO source_log VALUES(36,'greenhouse','Clean Air Task Force (CATF)','2026-05-29T10:51:36+00:00','error',0,0,0,'HTTP 404: {"status":404,"error":"Job board not found"}',90);
INSERT INTO source_log VALUES(37,'greenhouse','Center for Climate and Energy Solutions (C2ES)','2026-05-29T10:51:37+00:00','error',0,0,0,'HTTP 404: {"status":404,"error":"Job board not found"}',63);
INSERT INTO source_log VALUES(38,'greenhouse','Ceres','2026-05-29T10:51:38+00:00','error',0,0,0,'HTTP 404: {"status":404,"error":"Job board not found"}',109);
INSERT INTO source_log VALUES(39,'greenhouse','BlueGreen Alliance','2026-05-29T10:51:39+00:00','error',0,0,0,'HTTP 404: {"status":404,"error":"Job board not found"}',72);
INSERT INTO source_log VALUES(40,'greenhouse','Bipartisan Policy Center','2026-05-29T10:51:40+00:00','error',0,0,0,'HTTP 404: {"status":404,"error":"Job board not found"}',76);
INSERT INTO source_log VALUES(41,'greenhouse','New America Foundation','2026-05-29T10:51:41+00:00','error',0,0,0,'HTTP 404: {"status":404,"error":"Job board not found"}',129);
INSERT INTO source_log VALUES(42,'greenhouse','Rockefeller Foundation','2026-05-29T10:51:43+00:00','error',0,0,0,'HTTP 404: {"status":404,"error":"Job board not found"}',84);
INSERT INTO source_log VALUES(43,'greenhouse','Bloomberg Philanthropies','2026-05-29T10:51:44+00:00','error',0,0,0,'HTTP 404: {"status":404,"error":"Job board not found"}',57);
INSERT INTO source_log VALUES(44,'greenhouse','Hewlett Foundation','2026-05-29T10:51:45+00:00','error',0,0,0,'HTTP 404: {"status":404,"error":"Job board not found"}',93);
INSERT INTO source_log VALUES(45,'greenhouse','IREX','2026-05-29T10:51:46+00:00','error',0,0,0,'HTTP 404: {"status":404,"error":"Job board not found"}',94);
INSERT INTO source_log VALUES(46,'greenhouse','Freedom House','2026-05-29T10:51:47+00:00','error',0,0,0,'HTTP 404: {"status":404,"error":"Job board not found"}',60);
INSERT INTO source_log VALUES(47,'greenjobs','GreenJobs.com (aggregated)','2026-05-29T10:51:47+00:00','success',20,2,18,NULL,14546);
INSERT INTO source_log VALUES(48,'neogov','Fairfax County Government','2026-05-29T10:52:02+00:00','error',0,0,0,'HTTP 400: Bad Request',478);
INSERT INTO source_log VALUES(49,'neogov','Arlington County Government','2026-05-29T10:52:04+00:00','error',0,0,0,'HTTP 400: Bad Request',392);
INSERT INTO source_log VALUES(50,'neogov','Montgomery County Government (MD)','2026-05-29T10:52:05+00:00','error',0,0,0,'HTTP 400: Bad Request',390);
INSERT INTO source_log VALUES(51,'neogov','Prince George''s County (MD)','2026-05-29T10:52:06+00:00','error',0,0,0,'HTTP 400: Bad Request',404);
INSERT INTO source_log VALUES(52,'neogov','City of Alexandria (VA)','2026-05-29T10:52:08+00:00','error',0,0,0,'HTTP 400: Bad Request',418);
INSERT INTO source_log VALUES(53,'neogov','Falls Church City (VA)','2026-05-29T10:52:09+00:00','error',0,0,0,'HTTP 400: Bad Request',418);
INSERT INTO source_log VALUES(54,'neogov','City of Rockville (MD)','2026-05-29T10:52:11+00:00','error',0,0,0,'request failed: HTTPSConnectionPool(host=''www.governmentjobs.com'', port=443): Max retries exceeded with url: /SearchEngine/JobsFeed?agency= (Caused by ConnectTimeoutError(<HTTPSConnection(host=''www.governmentjobs.com'', port=443) at 0x7f337401b910>, ''Connection to www.governmentjobs.com timed out. (connect timeout=30)''))',30047);
INSERT INTO source_log VALUES(55,'neogov','Loudoun County (VA)','2026-05-29T10:52:42+00:00','error',0,0,0,'request failed: HTTPSConnectionPool(host=''www.governmentjobs.com'', port=443): Max retries exceeded with url: /SearchEngine/JobsFeed?agency= (Caused by ConnectTimeoutError(<HTTPSConnection(host=''www.governmentjobs.com'', port=443) at 0x7f3374024650>, ''Connection to www.governmentjobs.com timed out. (connect timeout=30)''))',30034);
INSERT INTO source_log VALUES(56,'neogov','Prince William County (VA)','2026-05-29T10:53:13+00:00','error',0,0,0,'request failed: HTTPSConnectionPool(host=''www.governmentjobs.com'', port=443): Max retries exceeded with url: /SearchEngine/JobsFeed?agency= (Caused by ConnectTimeoutError(<HTTPSConnection(host=''www.governmentjobs.com'', port=443) at 0x7f337400ef50>, ''Connection to www.governmentjobs.com timed out. (connect timeout=30)''))',30063);
CREATE TABLE url_telemetry (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    url             TEXT NOT NULL,
    domain          TEXT NOT NULL,          -- normalized hostname, e.g. 'boards.greenhouse.io'
    ats_guess       TEXT NOT NULL,          -- canonical ATS id; 'unknown' for unrecognized
    ats_slug        TEXT,                   -- tenant/company slug when extractable
    company_name    TEXT,                   -- as known to the posting (may be NULL)
    source          TEXT NOT NULL,          -- 'greenhouse', 'jobspy:indeed', 'manual', ...
    added_at        TEXT NOT NULL,          -- ISO-8601 UTC, first time we saw this URL from this source
    posting_id      INTEGER,                -- FK to postings.id; NULL if telemetry written before posting committed

    FOREIGN KEY (posting_id) REFERENCES postings(id),
    UNIQUE (url, source)
);
INSERT INTO url_telemetry VALUES(1,'https://greenjobs.greenjobsearch.org/jobs/sustainability-enforcement-attorney/','greenjobs.greenjobsearch.org','unknown',NULL,'NYC Department of Buildings','greenjobs','2026-05-27T10:59:03+00:00',1);
INSERT INTO url_telemetry VALUES(2,'https://greenjobs.greenjobsearch.org/jobs/advocacy-director-2/','greenjobs.greenjobsearch.org','unknown',NULL,'Permit Power','greenjobs','2026-05-27T10:59:03+00:00',2);
INSERT INTO url_telemetry VALUES(3,'https://greenjobs.greenjobsearch.org/jobs/landscape-technician-gardener-2/','greenjobs.greenjobsearch.org','unknown',NULL,'Mad Hatter Garden Designs','greenjobs','2026-05-27T10:59:03+00:00',3);
INSERT INTO url_telemetry VALUES(4,'https://greenjobs.greenjobsearch.org/jobs/research-manager/','greenjobs.greenjobsearch.org','unknown',NULL,'Energy and Policy Institute','greenjobs','2026-05-27T10:59:03+00:00',4);
INSERT INTO url_telemetry VALUES(5,'https://greenjobs.greenjobsearch.org/jobs/research-fellow-3/','greenjobs.greenjobsearch.org','unknown',NULL,'Energy and Policy Institute','greenjobs','2026-05-27T10:59:03+00:00',5);
INSERT INTO url_telemetry VALUES(6,'https://greenjobs.greenjobsearch.org/jobs/texas-regional-organizer/','greenjobs.greenjobsearch.org','unknown',NULL,'Beyond Petrochemicals','greenjobs','2026-05-27T10:59:03+00:00',6);
INSERT INTO url_telemetry VALUES(7,'https://greenjobs.greenjobsearch.org/jobs/gardener-4/','greenjobs.greenjobsearch.org','unknown',NULL,'Smiling Gardens','greenjobs','2026-05-27T10:59:03+00:00',7);
INSERT INTO url_telemetry VALUES(8,'https://greenjobs.greenjobsearch.org/jobs/regional-wildlife-program-manager-region-1-wms-band-2/','greenjobs.greenjobsearch.org','unknown',NULL,'Region 1 - WMS Band 2 - Washington Department of Fish & Wildlife','greenjobs','2026-05-27T10:59:03+00:00',8);
INSERT INTO url_telemetry VALUES(9,'https://greenjobs.greenjobsearch.org/jobs/americorps-project-conserve-member/','greenjobs.greenjobsearch.org','unknown',NULL,'Conserving Carolina','greenjobs','2026-05-27T10:59:03+00:00',9);
INSERT INTO url_telemetry VALUES(10,'https://greenjobs.greenjobsearch.org/jobs/minnesota-greencorps-americorps-member-4/','greenjobs.greenjobsearch.org','unknown',NULL,'State of Minnesota','greenjobs','2026-05-27T10:59:03+00:00',10);
INSERT INTO url_telemetry VALUES(11,'https://greenjobs.greenjobsearch.org/jobs/environmental-services-manager/','greenjobs.greenjobsearch.org','unknown',NULL,'The Woodlands Township','greenjobs','2026-05-27T10:59:03+00:00',11);
INSERT INTO url_telemetry VALUES(12,'https://greenjobs.greenjobsearch.org/jobs/deputy-director-alternative-energy/','greenjobs.greenjobsearch.org','unknown',NULL,'NYC Department of Buildings','greenjobs','2026-05-27T10:59:03+00:00',12);
INSERT INTO url_telemetry VALUES(13,'https://greenjobs.greenjobsearch.org/jobs/solid-waste-manager/','greenjobs.greenjobsearch.org','unknown',NULL,'Thurston County Public Works','greenjobs','2026-05-27T10:59:03+00:00',13);
INSERT INTO url_telemetry VALUES(14,'https://greenjobs.greenjobsearch.org/jobs/executive-director-200/','greenjobs.greenjobsearch.org','unknown',NULL,'Equity Trust, Inc.','greenjobs','2026-05-27T10:59:03+00:00',14);
INSERT INTO url_telemetry VALUES(15,'https://greenjobs.greenjobsearch.org/jobs/south-coastkeeper/','greenjobs.greenjobsearch.org','unknown',NULL,'Save The Bay','greenjobs','2026-05-27T10:59:03+00:00',15);
INSERT INTO url_telemetry VALUES(16,'https://greenjobs.greenjobsearch.org/jobs/president-11/','greenjobs.greenjobsearch.org','unknown',NULL,'The Land Conservancy of New Jersey','greenjobs','2026-05-27T10:59:03+00:00',16);
INSERT INTO url_telemetry VALUES(17,'https://greenjobs.greenjobsearch.org/jobs/pacific-education-institute-executive-director/','greenjobs.greenjobsearch.org','unknown',NULL,'Pacific Education Institute','greenjobs','2026-05-27T10:59:03+00:00',17);
INSERT INTO url_telemetry VALUES(18,'https://greenjobs.greenjobsearch.org/jobs/new-england-policy-manager/','greenjobs.greenjobsearch.org','unknown',NULL,'American Farmland Trust','greenjobs','2026-05-27T10:59:03+00:00',18);
INSERT INTO url_telemetry VALUES(19,'https://greenjobs.greenjobsearch.org/jobs/midwest-program-manager/','greenjobs.greenjobsearch.org','unknown',NULL,'Land Trust Alliance','greenjobs','2026-05-27T10:59:03+00:00',19);
INSERT INTO url_telemetry VALUES(20,'https://greenjobs.greenjobsearch.org/jobs/emergency-response-team-americorps-member/','greenjobs.greenjobsearch.org','unknown',NULL,'AmeriCorps St. Louis','greenjobs','2026-05-27T10:59:03+00:00',20);
INSERT INTO url_telemetry VALUES(21,'https://greenjobs.greenjobsearch.org/jobs/media-communications-summer-intern/','greenjobs.greenjobsearch.org','unknown',NULL,'Smart Surfaces Coalition','greenjobs','2026-05-29T10:51:48+00:00',21);
INSERT INTO url_telemetry VALUES(22,'https://greenjobs.greenjobsearch.org/jobs/regional-farmland-preservation-program-coordinator/','greenjobs.greenjobsearch.org','unknown',NULL,'NJ Farmland Preservation Program/State Agriculture Development Committee (SADC)','greenjobs','2026-05-29T10:51:48+00:00',22);
CREATE TABLE achievements (
    id          TEXT PRIMARY KEY,
    name        TEXT NOT NULL,
    description TEXT NOT NULL,
    icon        TEXT NOT NULL,
    earned_at   TEXT,
    seen_at     TEXT
);
INSERT INTO achievements VALUES('first_app','First brave step','Sent your first application','🌱',NULL,NULL);
INSERT INTO achievements VALUES('tailor_5','Tailor''s apprentice','Tailored 5 resumes','🧵',NULL,NULL);
INSERT INTO achievements VALUES('week_streak','Week one warrior','7-day streak','🔥',NULL,NULL);
INSERT INTO achievements VALUES('interview','First interview','Status → Interviewing','💬',NULL,NULL);
INSERT INTO achievements VALUES('apps_10','Double digits','10 applications submitted','🏅',NULL,NULL);
INSERT INTO achievements VALUES('weekly_15','Quota crusher','Hit 15 in a week','🚀',NULL,NULL);
INSERT INTO achievements VALUES('month_streak','Steady gardener','30-day streak','🌳',NULL,NULL);
INSERT INTO achievements VALUES('offer','The big one','Receive an offer','🌟',NULL,NULL);
DELETE FROM sqlite_sequence;
INSERT INTO sqlite_sequence VALUES('source_log',56);
INSERT INTO sqlite_sequence VALUES('postings',40);
INSERT INTO sqlite_sequence VALUES('url_telemetry',40);
CREATE INDEX idx_postings_company        ON postings(company);
CREATE INDEX idx_postings_first_seen     ON postings(first_seen);
CREATE INDEX idx_postings_is_active      ON postings(is_active);
CREATE INDEX idx_postings_fit_score      ON postings(fit_score);
CREATE INDEX idx_postings_interest_level ON postings(interest_level);
CREATE INDEX idx_applications_posting_id ON applications(posting_id);
CREATE INDEX idx_applications_status     ON applications(status);
CREATE INDEX idx_source_log_run_at ON source_log(run_at);
CREATE INDEX idx_source_log_source ON source_log(source);
CREATE INDEX idx_url_telemetry_domain    ON url_telemetry(domain);
CREATE INDEX idx_url_telemetry_ats_guess ON url_telemetry(ats_guess);
CREATE INDEX idx_url_telemetry_ats_slug  ON url_telemetry(ats_slug);
CREATE INDEX idx_url_telemetry_source    ON url_telemetry(source);
CREATE INDEX idx_url_telemetry_added_at  ON url_telemetry(added_at);
COMMIT;
